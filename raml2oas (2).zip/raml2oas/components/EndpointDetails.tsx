'use client';

import { useState } from 'react';

interface EndpointDetailsProps {
  endpoint: any;
  onBack: () => void;
}

export default function EndpointDetails({ endpoint, onBack }: EndpointDetailsProps) {
  const [activeTab, setActiveTab] = useState<'request' | 'response'>('request');
  const [copiedMessage, setCopiedMessage] = useState<string>('');

  const generateCurl = () => {
    const headers = endpoint.parameters.filter((p: any) => p.in === 'header');
    const queryParams = endpoint.parameters.filter((p: any) => p.in === 'query');
    const pathParams = endpoint.parameters.filter((p: any) => p.in === 'path');

    // Replace path parameters with example values
    let url = endpoint.path;
    pathParams.forEach((param: any) => {
      const exampleValue = param.enum?.[0] || `{${param.name}}`;
      url = url.replace(`{${param.name}}`, exampleValue);
    });

    // Add query parameters
    if (queryParams.length > 0) {
      const queryString = queryParams.map((param: any) => {
        const exampleValue = param.enum?.[0] || `${param.name}_value`;
        return `${param.name}=${exampleValue}`;
      }).join('&');
      url += `?${queryString}`;
    }

    let curl = `curl -X ${endpoint.method} 'https://api.example.com${url}'`;

    // Add headers
    headers.forEach((header: any) => {
      const exampleValue = header.enum?.[0] || `${header.name}_value`;
      curl += ` \\\n  -H '${header.name}: ${exampleValue}'`;
    });

    // Add request body
    if (endpoint.requestBody && endpoint.requestBody.fields.length > 0) {
      curl += ` \\\n  -H 'Content-Type: application/json'`;
      const bodyExample = generateBodyExample(endpoint.requestBody.fields);
      curl += ` \\\n  -d '${JSON.stringify(bodyExample, null, 2)}'`;
    }

    return curl;
  };

  const generateBodyExample = (fields: any[]): any => {
    // Check if the root is an array (path starts with [])
    const isRootArray = fields.length > 0 && fields[0].path.startsWith('[]');
    
    if (isRootArray) {
      // For array responses, create a single example object
      const exampleItem: any = {};
      
      fields.forEach((field: any) => {
        // Remove the leading []
        const pathWithoutRoot = field.path.replace(/^\[\]\./, '');
        const pathParts = pathWithoutRoot.split('.');
        let current = exampleItem;
        
        for (let i = 0; i < pathParts.length - 1; i++) {
          const part = pathParts[i].replace(/\[\]/g, '');
          if (!part) continue; // Skip empty parts
          
          if (!current[part]) {
            // If this part contains [], create an array with one example object
            if (pathParts[i].includes('[]')) {
              current[part] = [{}];
              current = current[part][0];
            } else {
              current[part] = {};
              current = current[part];
            }
          } else {
            current = pathParts[i].includes('[]') ? current[part][0] : current[part];
          }
        }
        
        const lastPart = pathParts[pathParts.length - 1].replace(/\[\]/g, '');
        if (lastPart && typeof current === 'object' && !Array.isArray(current)) {
          current[lastPart] = field.enum?.[0] || getExampleValue(field.type, field.format);
        }
      });
      
      return [exampleItem]; // Return as array with one example item
    }
    
    // For object responses
    const body: any = {};
    
    fields.forEach((field: any) => {
      // Skip fields that are pure array types without nested path (like "items" with type "array")
      // These are just container declarations, the actual fields come as "items[].fieldName"
      if (field.type === 'array' && !field.path.includes('[]')) {
        return;
      }
      
      const pathParts = field.path.split('.');
      let current = body;
      
      for (let i = 0; i < pathParts.length - 1; i++) {
        const part = pathParts[i].replace(/\[\]/g, '');
        if (!part) continue; // Skip empty parts
        
        if (!current[part]) {
          // If this part contains [], create an array with one example object
          if (pathParts[i].includes('[]')) {
            current[part] = [{}];
            current = current[part][0];
          } else {
            current[part] = {};
            current = current[part];
          }
        } else {
          current = pathParts[i].includes('[]') ? current[part][0] : current[part];
        }
      }
      
      const lastPart = pathParts[pathParts.length - 1].replace(/\[\]/g, '');
      if (lastPart && typeof current === 'object' && !Array.isArray(current)) {
        current[lastPart] = field.enum?.[0] || getExampleValue(field.type, field.format);
      }
    });
    
    return body;
  };

  const getExampleValue = (type: string, format?: string): any => {
    if (format === 'date-time') return '2024-01-01T00:00:00Z';
    if (format === 'date') return '2024-01-01';
    if (format === 'email') return 'user@example.com';
    if (format === 'uri') return 'https://example.com';
    
    switch (type) {
      case 'string': return 'string_value';
      case 'integer': return 123;
      case 'number': return 123.45;
      case 'boolean': return true;
      case 'array': return [];
      case 'object': return {};
      default: return 'value';
    }
  };

  const generateResponseExample = (statusCode: string) => {
    const response = endpoint.responses[statusCode];
    if (!response || response.fields.length === 0) {
      return { message: 'Success' };
    }
    return generateBodyExample(response.fields);
  };

  const copyToClipboard = async (text: string, message: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedMessage(message);
      setTimeout(() => setCopiedMessage(''), 2000);
    } catch (err) {
      alert('Failed to copy to clipboard');
    }
  };

  const renderParametersTable = (parameters: any[]) => {
    if (!parameters || parameters.length === 0) {
      return <p className="text-gray-500 text-sm">No parameters defined</p>;
    }

    const headers = parameters.filter((p: any) => p.in === 'header');
    const queryParams = parameters.filter((p: any) => p.in === 'query');
    const pathParams = parameters.filter((p: any) => p.in === 'path');

    const renderTable = (params: any[], title: string) => {
      if (params.length === 0) return null;

      return (
        <div className="mb-6">
          <h4 className="text-sm font-semibold text-gray-700 mb-2">{title}</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white border border-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Name</th>
                  <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Type</th>
                  <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Required</th>
                  <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Pattern</th>
                  <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Min/Max</th>
                  <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Enum</th>
                  <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Description</th>
                </tr>
              </thead>
              <tbody>
                {params.map((param: any, idx: number) => (
                  <tr key={idx} className="hover:bg-gray-50">
                    <td className="px-4 py-2 text-sm border-b font-mono">{param.name}</td>
                    <td className="px-4 py-2 text-sm border-b">
                      <code className="bg-gray-100 px-2 py-1 rounded text-xs">
                        {param.type}{param.format ? ` (${param.format})` : ''}
                      </code>
                    </td>
                    <td className="px-4 py-2 text-sm border-b">
                      <span className={`px-2 py-1 rounded text-xs font-semibold ${param.required ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-600'}`}>
                        {param.required ? 'Required' : 'Optional'}
                      </span>
                    </td>
                    <td className="px-4 py-2 text-sm border-b">
                      {param.pattern ? (
                        <code className="bg-[#e6f7fd] px-2 py-1 rounded text-xs text-[#00AEEF]">{param.pattern}</code>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="px-4 py-2 text-sm border-b">
                      {param.minLength !== undefined || param.maxLength !== undefined || param.minimum !== undefined || param.maximum !== undefined ? (
                        <div className="text-xs">
                          {param.minLength !== undefined && <div>Min Length: {param.minLength}</div>}
                          {param.maxLength !== undefined && <div>Max Length: {param.maxLength}</div>}
                          {param.minimum !== undefined && <div>Min: {param.minimum}</div>}
                          {param.maximum !== undefined && <div>Max: {param.maximum}</div>}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="px-4 py-2 text-sm border-b">
                      {param.enum ? (
                        <div className="text-xs space-y-1">
                          {param.enum.map((val: any, i: number) => (
                            <code key={i} className="bg-purple-50 px-2 py-1 rounded block text-purple-800">{val}</code>
                          ))}
                        </div>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="px-4 py-2 text-sm border-b text-gray-600">{param.description || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      );
    };

    return (
      <>
        {renderTable(pathParams, 'Path Parameters')}
        {renderTable(queryParams, 'Query Parameters')}
        {renderTable(headers, 'Header Parameters')}
      </>
    );
  };

  const renderFieldsTable = (fields: any[], title: string) => {
    if (!fields || fields.length === 0) {
      return <p className="text-gray-500 text-sm">No {title.toLowerCase()} defined</p>;
    }

    return (
      <div className="mb-6">
        <h4 className="text-sm font-semibold text-gray-700 mb-2">{title}</h4>
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Field Name</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">JSON Path</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Type</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Required</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Pattern</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Min/Max</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Enum</th>
                <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 border-b">Description</th>
              </tr>
            </thead>
            <tbody>
              {fields.map((field: any, idx: number) => (
                <tr key={idx} className="hover:bg-gray-50">
                  <td className="px-4 py-2 text-sm border-b font-mono">{field.name}</td>
                  <td className="px-4 py-2 text-sm border-b">
                    <code className="bg-[#e6f7fd] px-2 py-1 rounded text-xs text-[#00AEEF]">{field.path}</code>
                  </td>
                  <td className="px-4 py-2 text-sm border-b">
                    <code className="bg-gray-100 px-2 py-1 rounded text-xs">
                      {field.type}{field.format ? ` (${field.format})` : ''}
                    </code>
                  </td>
                  <td className="px-4 py-2 text-sm border-b">
                    <span className={`px-2 py-1 rounded text-xs font-semibold ${field.required ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-600'}`}>
                      {field.required ? 'Required' : 'Optional'}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-sm border-b">
                    {field.pattern ? (
                      <code className="bg-[#e6f7fd] px-2 py-1 rounded text-xs text-[#00AEEF]">{field.pattern}</code>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className="px-4 py-2 text-sm border-b">
                    {field.minLength !== undefined || field.maxLength !== undefined || field.minimum !== undefined || field.maximum !== undefined ? (
                      <div className="text-xs">
                        {field.minLength !== undefined && <div>Min Length: {field.minLength}</div>}
                        {field.maxLength !== undefined && <div>Max Length: {field.maxLength}</div>}
                        {field.minimum !== undefined && <div>Min: {field.minimum}</div>}
                        {field.maximum !== undefined && <div>Max: {field.maximum}</div>}
                      </div>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className="px-4 py-2 text-sm border-b">
                    {field.enum ? (
                      <div className="text-xs space-y-1">
                        {field.enum.map((val: any, i: number) => (
                          <code key={i} className="bg-purple-50 px-2 py-1 rounded block text-purple-800">{val}</code>
                        ))}
                      </div>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className="px-4 py-2 text-sm border-b text-gray-600">{field.description || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const renderResponseTable = (responses: any) => {
    const statusCodes = Object.keys(responses);
    if (statusCodes.length === 0) {
      return <p className="text-gray-500 text-sm">No responses defined</p>;
    }

    return (
      <div className="space-y-6">
        {statusCodes.map((statusCode) => {
          const response = responses[statusCode];
          return (
            <div key={statusCode} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded font-semibold text-sm ${
                    statusCode.startsWith('2') ? 'bg-green-100 text-green-800' :
                    statusCode.startsWith('4') ? 'bg-orange-100 text-orange-800' :
                    statusCode.startsWith('5') ? 'bg-red-100 text-red-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {statusCode}
                  </span>
                  <span className="text-sm text-gray-600">{response.description}</span>
                </div>
                <button
                  onClick={() => {
                    const example = generateResponseExample(statusCode);
                    copyToClipboard(JSON.stringify(example, null, 2), 'Response JSON copied!');
                  }}
                  className="px-3 py-1 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 text-xs font-semibold transition-colors"
                >
                  Copy JSON Response
                </button>
              </div>
              {renderFieldsTable(response.fields, `Response Fields`)}
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <button
          onClick={onBack}
          className="mb-4 text-[#00AEEF] hover:text-[#0082b9] font-semibold text-sm flex items-center gap-2"
        >
          Back to Endpoints
        </button>

        <div className="border-b border-gray-200 pb-4 mb-6">
          <div className="flex items-center gap-3 mb-2">
            <span className={`px-3 py-1 rounded font-semibold text-sm ${
              endpoint.method === 'GET' ? 'bg-[#e6f7fd] text-[#00AEEF]' :
              endpoint.method === 'POST' ? 'bg-green-100 text-green-800' :
              endpoint.method === 'PUT' ? 'bg-orange-100 text-orange-800' :
              endpoint.method === 'PATCH' ? 'bg-yellow-100 text-yellow-800' :
              endpoint.method === 'DELETE' ? 'bg-red-100 text-red-800' :
              'bg-gray-100 text-gray-800'
            }`}>
              {endpoint.method}
            </span>
            <code className="text-lg font-mono text-gray-800">{endpoint.path}</code>
          </div>
          {endpoint.summary && <p className="text-gray-700 font-semibold">{endpoint.summary}</p>}
          {endpoint.description && <p className="text-gray-600 text-sm mt-1">{endpoint.description}</p>}
        </div>

        {copiedMessage && (
          <div className="mb-4 bg-green-50 border border-green-200 text-green-800 px-4 py-2 rounded-lg text-sm font-semibold">
            {copiedMessage}
          </div>
        )}

        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setActiveTab('request')}
            className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
              activeTab === 'request'
                ? 'bg-[#00AEEF] text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Request Details
          </button>
          <button
            onClick={() => setActiveTab('response')}
            className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
              activeTab === 'response'
                ? 'bg-[#00AEEF] text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Response Details
          </button>
          {activeTab === 'request' && (
            <button
              onClick={() => copyToClipboard(generateCurl(), 'cURL command copied!')}
              className="ml-auto px-4 py-2 bg-[#e6f7fd] text-[#00AEEF] rounded-lg hover:bg-[#b3e7f9] font-semibold text-sm transition-colors"
            >
              Copy as cURL
            </button>
          )}
        </div>

        {activeTab === 'request' ? (
          <div>
            <h3 className="text-lg font-bold text-gray-800 mb-4">Request Details</h3>
            
            {renderParametersTable(endpoint.parameters)}
            
            {endpoint.requestBody && (
              <div className="mt-6">
                {renderFieldsTable(endpoint.requestBody.fields, 'Request Body Fields')}
              </div>
            )}

            {!endpoint.requestBody && endpoint.parameters.length === 0 && (
              <p className="text-gray-500 text-sm">No request parameters or body defined</p>
            )}
          </div>
        ) : (
          <div>
            <h3 className="text-lg font-bold text-gray-800 mb-4">Response Details</h3>
            {renderResponseTable(endpoint.responses)}
          </div>
        )}
      </div>
    </div>
  );
}
