import { NextRequest, NextResponse } from 'next/server';
import JSZip from 'jszip';
import { flattenOas } from '@/lib/converter';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      );
    }

    // Read the ZIP file
    const arrayBuffer = await file.arrayBuffer();
    const zip = new JSZip();
    const zipContents = await zip.loadAsync(arrayBuffer);

    // Extract all files from ZIP
    const files: { [key: string]: string } = {};
    const filePromises: Promise<void>[] = [];

    zipContents.forEach((relativePath, zipEntry) => {
      if (!zipEntry.dir) {
        filePromises.push(
          zipEntry.async('string').then((content) => {
            files[relativePath] = content;
          })
        );
      }
    });

    await Promise.all(filePromises);

    // Find the main OpenAPI file
    const mainOasFile = Object.keys(files).find(
      (path) => 
        (path.endsWith('.yaml') || path.endsWith('.yml') || path.endsWith('.json')) && 
        (path.includes('openapi') || path.includes('swagger') || path === 'api.yaml' || path === 'api.yml' || path === 'api.json' || !path.includes('/'))
    );

    if (!mainOasFile) {
      return NextResponse.json(
        { error: 'No main OpenAPI file found in ZIP. Looking for openapi.yaml, swagger.yaml, api.yaml, or similar.' },
        { status: 400 }
      );
    }

    // Flatten OAS
    const flattenedOas = await flattenOas(files, mainOasFile);

    return NextResponse.json({
      success: true,
      oas: flattenedOas,
      originalFile: mainOasFile
    });

  } catch (error: any) {
    console.error('OAS Flattening error:', error);
    return NextResponse.json(
      { 
        error: error.message || 'Failed to flatten OpenAPI',
        details: error.stack
      },
      { status: 500 }
    );
  }
}
