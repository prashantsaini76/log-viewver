import { NextRequest, NextResponse } from 'next/server';
import JSZip from 'jszip';
import { convertRamlToOas } from '@/lib/converter';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      );
    }

    if (!file.name.endsWith('.zip')) {
      return NextResponse.json(
        { error: 'File must be a ZIP archive' },
        { status: 400 }
      );
    }

    // Read the ZIP file
    const arrayBuffer = await file.arrayBuffer();
    const zip = new JSZip();
    const zipContent = await zip.loadAsync(arrayBuffer);

    // Extract all files from ZIP
    const files: { [path: string]: string } = {};
    const fileNames = Object.keys(zipContent.files);

    for (const fileName of fileNames) {
      const zipEntry = zipContent.files[fileName];
      if (!zipEntry.dir) {
        const content = await zipEntry.async('text');
        files[fileName] = content;
      }
    }

    if (Object.keys(files).length === 0) {
      return NextResponse.json(
        { error: 'ZIP file is empty' },
        { status: 400 }
      );
    }

    // Find the main RAML file (typically api.raml or *.raml in root)
    let mainRamlFile: string | undefined = fileNames.find(
      (name) => name === 'api.raml' || name === 'main.raml'
    );

    if (!mainRamlFile) {
      // Look for any .raml file in the root directory
      mainRamlFile = fileNames.find(
        (name) => !name.includes('/') && name.endsWith('.raml')
      );
    }

    if (!mainRamlFile) {
      return NextResponse.json(
        { error: 'No main RAML file found (expected api.raml or *.raml in root)' },
        { status: 400 }
      );
    }

    // Convert RAML to OAS
    const result = await convertRamlToOas(files, mainRamlFile);

    return NextResponse.json({
      success: true,
      oas: result.oas,
      yaml: result.yaml,
      filesProcessed: Object.keys(files).length,
      mainFile: mainRamlFile,
    });
  } catch (error) {
    console.error('Conversion error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Conversion failed',
        details: error instanceof Error ? error.stack : undefined,
      },
      { status: 500 }
    );
  }
}
