import { NextRequest, NextResponse } from 'next/server';
import JSZip from 'jszip';
import { exploreOAS } from '@/lib/converter';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      );
    }

    // Read the ZIP file
    const arrayBuffer = await file.arrayBuffer();
    const zip = new JSZip();
    const zipContents = await zip.loadAsync(arrayBuffer);

    // Extract all files from ZIP
    const files: { [key: string]: string } = {};
    const filePromises: Promise<void>[] = [];

    zipContents.forEach((relativePath, zipEntry) => {
      if (!zipEntry.dir) {
        filePromises.push(
          zipEntry.async('string').then((content) => {
            files[relativePath] = content;
          })
        );
      }
    });

    await Promise.all(filePromises);

    // Find the main OAS file
    const mainOasFile = Object.keys(files).find(
      (filePath) => {
        const fileName = filePath.split('/').pop()?.toLowerCase() || '';
        return (
          fileName === 'openapi.yaml' || 
          fileName === 'openapi.yml' || 
          fileName === 'openapi.json' ||
          fileName === 'swagger.yaml' || 
          fileName === 'swagger.yml' || 
          fileName === 'swagger.json' ||
          fileName === 'api.yaml' || 
          fileName === 'api.yml' ||
          fileName === 'api.json'
        );
      }
    );

    if (!mainOasFile) {
      return NextResponse.json(
        { 
          error: 'No OpenAPI file found in ZIP. Expected: openapi.yaml, swagger.yaml, or api.yaml',
          availableFiles: Object.keys(files).filter(f => f.endsWith('.yaml') || f.endsWith('.yml') || f.endsWith('.json'))
        },
        { status: 400 }
      );
    }

    // Explore OAS and extract all endpoints
    const exploration = await exploreOAS(files, mainOasFile);

    console.log('Exploration result:', JSON.stringify(exploration, null, 2));

    return NextResponse.json({
      success: true,
      exploration
    });

  } catch (error: any) {
    console.error('Exploration error:', error);
    return NextResponse.json(
      { 
        error: error.message || 'Failed to explore OAS',
        details: error.stack
      },
      { status: 500 }
    );
  }
}
