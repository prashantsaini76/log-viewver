import { convertRamlToOas } from './lib/converter.ts';
import * as fs from 'fs';
import * as path from 'path';

async function test() {
  console.log('Testing examples support...\n');

  // Read all RAML files
  const files = {
    'api.raml': fs.readFileSync('raml-sample-api/api.raml', 'utf8'),
    'libraries/common-types.raml': fs.readFileSync('raml-sample-api/libraries/common-types.raml', 'utf8'),
    'libraries/error-types.raml': fs.readFileSync('raml-sample-api/libraries/error-types.raml', 'utf8'),
    'resources/users/users.raml': fs.readFileSync('raml-sample-api/resources/users/users.raml', 'utf8'),
    'resources/users/user-by-id.raml': fs.readFileSync('raml-sample-api/resources/users/user-by-id.raml', 'utf8'),
    'resources/orders/orders.raml': fs.readFileSync('raml-sample-api/resources/orders/orders.raml', 'utf8'),
    'traits/secured.raml': fs.readFileSync('raml-sample-api/traits/secured.raml', 'utf8'),
    'traits/pageable.raml': fs.readFileSync('raml-sample-api/traits/pageable.raml', 'utf8'),
    'examples/user-example.json': fs.readFileSync('raml-sample-api/examples/user-example.json', 'utf8'),
    'examples/order-example.json': fs.readFileSync('raml-sample-api/examples/order-example.json', 'utf8'),
  };

  try {
    const result = await convertRamlToOas(files, 'api.raml');
    console.log('✅ SUCCESS! Conversion completed.\n');
    
    // Check if examples are present
    const oasObj = result.oas; // Already an object, not a string
    
    console.log('Checking for examples in OAS...\n');
    
    // Check User type example
    if (oasObj.components?.schemas?.User?.example) {
      console.log('✅ User schema has example:', JSON.stringify(oasObj.components.schemas.User.example, null, 2));
    } else {
      console.log('❌ User schema missing example');
    }
    
    // Check response examples at media type level
    const getUsersContent = oasObj.paths?.['/users']?.get?.responses?.['200']?.content?.['application/json'];
    if (getUsersContent?.examples) {
      console.log('\n✅ GET /users response has examples at media type level:');
      console.log(JSON.stringify(getUsersContent.examples, null, 2));
    } else {
      console.log('\n❌ GET /users response missing examples at media type level');
      console.log('Full content object:', JSON.stringify(getUsersContent, null, 2).substring(0, 500));
    }
    
    fs.writeFileSync('test-examples-output.yaml', result.yaml);
    console.log('\n📝 Full output written to test-examples-output.yaml');
    
  } catch (error) {
    console.error('❌ Conversion failed:', error.message);
    if (error.stack) console.error(error.stack);
  }
}

test();
