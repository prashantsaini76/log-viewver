const fs = require('fs');
const { convertRamlToOas } = require('./lib/converter.ts');

async function testLocalTypes() {
  console.log('Testing local type references in library...\n');
  
  const files = {
    'test-local-types.raml': fs.readFileSync('test-local-types.raml', 'utf-8'),
    'test-local-types-lib.raml': fs.readFileSync('test-local-types-lib.raml', 'utf-8'),
  };
  
  console.log('Files loaded:');
  Object.keys(files).forEach(f => console.log(`  ${f}`));
  console.log('');
  
  try {
    const result = await convertRamlToOas(files, 'test-local-types.raml');
    console.log('\n✅ Conversion successful!\n');
    
    // Check if attributes has the expanded type, not just "string"
    const postSchema = result.oas.paths['/users'].post.requestBody.content['application/json'].schema;
    console.log('POST /users request body schema:');
    console.log(JSON.stringify(postSchema, null, 2));
    
    // Navigate to attributes to see if it was expanded
    if (postSchema.properties && postSchema.properties.data && 
        postSchema.properties.data.properties && 
        postSchema.properties.data.properties.attributes) {
      const attributesSchema = postSchema.properties.data.properties.attributes;
      console.log('\n✅ Attributes schema:');
      console.log(JSON.stringify(attributesSchema, null, 2));
      
      if (attributesSchema.properties && attributesSchema.properties.name && attributesSchema.properties.email) {
        console.log('\n✅✅ SUCCESS! Local type reference UserDetails was expanded correctly!');
      } else {
        console.log('\n❌ FAILED! Attributes should have name and email properties');
      }
    }
  } catch (error) {
    console.error('\n❌ Conversion failed:');
    console.error(error.message);
  }
}

testLocalTypes();
