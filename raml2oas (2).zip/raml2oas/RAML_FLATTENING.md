# RAML Flattening Feature

## Overview

The RAML to OAS Converter now includes a **RAML Flattening** feature that consolidates multi-file RAML projects into a single `api.raml` file.

## What is RAML Flattening?

RAML projects often consist of multiple files organized across folders:
- Main API file (`api.raml`)
- Resource files in subfolders (`/resources/users/users.raml`)
- Library files with reusable types (`/libraries/common-types.raml`)
- Trait files for shared behaviors (`/traits/pageable.raml`)
- Example files (`/examples/user-example.json`)

The flattening feature resolves all `!include` directives and library references to create a single, standalone RAML file.

## Use Cases

### 1. **Simplified Sharing**
Share your API specification with teams without requiring the complex folder structure.

### 2. **Tool Compatibility**
Some RAML tools don't support multi-file projects. A flattened RAML works everywhere.

### 3. **Documentation**
Create standalone API documentation without external dependencies.

### 4. **Version Control**
Easier to track changes in a single file for certain workflows.

## How to Use

### Via Web UI

1. **Select Mode**: Choose "Flatten RAML" button at the top of the page
2. **Upload ZIP**: Upload your RAML project as a ZIP file
3. **Download**: Download the consolidated `api.raml` file

### What Gets Flattened

✅ **Resolved:**
- All `!include` directives (RAML files, JSON examples, etc.)
- Library type references (`uses:` blocks)
- Trait definitions from separate files
- Nested includes (includes within includes)

✅ **Preserved:**
- API structure and hierarchy
- All metadata (title, version, baseUri)
- Complete type definitions
- Resource paths and methods
- All documentation

❌ **Removed/Consolidated:**
- `uses:` block (libraries inlined with prefixes)
- `!include` directives (replaced with actual content)
- Multi-file structure (everything in one file)

## Example

### Before (Multi-File)

**api.raml:**
```yaml
#%RAML 1.0
title: My API
uses:
  types: libraries/common-types.raml
/users:
  !include resources/users/users.raml
```

**libraries/common-types.raml:**
```yaml
#%RAML 1.0 Library
types:
  User:
    type: object
    properties:
      id: integer
      name: string
```

**resources/users/users.raml:**
```yaml
get:
  responses:
    200:
      body:
        application/json:
          type: types.User[]
```

### After (Flattened)

**api.raml:**
```yaml
#%RAML 1.0
title: My API
types:
  types.User:
    type: object
    properties:
      id: integer
      name: string
/users:
  get:
    responses:
      200:
        body:
          application/json:
            type: types.User[]
```

## Technical Details

### Implementation

The flattening process:
1. Extracts all files from the uploaded ZIP
2. Resolves all `!include` directives recursively
3. Inlines library types with namespace prefixes
4. Removes the `uses:` block after inlining
5. Generates a single YAML file with all content

### Library Namespace Preservation

Library types are prefixed with their namespace to maintain references:
- `uses: { types: common-types.raml }` → types become `types.User`, `types.Order`
- All references are preserved: `type: types.User` still works

### Limitations

- **Large files**: Very complex projects may produce large single files
- **Comments**: Some YAML comments may be lost during parsing
- **External references**: URLs or external resources are not fetched
- **Binary files**: Binary content in includes may not be supported

## API Endpoint

The flattening feature is available via REST API:

```bash
POST /api/flatten
Content-Type: multipart/form-data

file: <raml-project.zip>
```

**Response:**
```json
{
  "success": true,
  "raml": "<flattened-raml-content>",
  "originalFile": "api.raml"
}
```

## Comparison with OAS Conversion

| Feature | RAML Flattening | OAS Conversion |
|---------|----------------|----------------|
| Output Format | RAML 1.0 | OpenAPI 3.0 |
| Purpose | Consolidate files | Convert format |
| Use Case | Simplify structure | API implementation |
| Content | Same as input | Transformed |
| Standards | RAML spec | OAS spec |

## Testing

Test the feature with the included sample:
1. Zip the `raml-sample-api` folder
2. Select "Flatten RAML" mode
3. Upload the ZIP file
4. Download and inspect the result

## Benefits

✅ **Portability**: Single file, easy to share
✅ **Compatibility**: Works with all RAML tools
✅ **Simplicity**: No folder structure needed
✅ **Version Control**: Easier diff tracking
✅ **Distribution**: Simple to embed or distribute

## Future Enhancements

Potential improvements:
- [ ] Option to preserve comments
- [ ] Custom namespace prefixes
- [ ] Selective flattening (choose which files)
- [ ] Format preservation options
- [ ] Validation after flattening
