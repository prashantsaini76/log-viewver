/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#e6f7fd',
          100: '#b3e7f9',
          200: '#80d7f5',
          300: '#4dc7f1',
          400: '#1ab7ed',
          500: '#00AEEF',
          600: '#0098d4',
          700: '#0082b9',
          800: '#006c9e',
          900: '#005683',
        },
      },
    },
  },
  plugins: [],
};
