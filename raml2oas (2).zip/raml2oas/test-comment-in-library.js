const fs = require('fs');
const { convertRamlToOas } = require('./lib/converter.ts');

console.log('Testing library path with inline comments...\n');

// Create a mock ZIP files object
const files = {
  'test-comment-in-library.raml': fs.readFileSync('test-comment-in-library.raml', 'utf8'),
  'test-library-traits-lib.raml': fs.readFileSync('test-library-traits-lib.raml', 'utf8'),
  'test-local-types-lib.raml': fs.readFileSync('test-local-types-lib.raml', 'utf8'),
  'test-trait-cacheable.raml': fs.readFileSync('test-trait-cacheable.raml', 'utf8'),
  'test-trait-not-cacheable.raml': fs.readFileSync('test-trait-not-cacheable.raml', 'utf8'),
  'test-trait-3.raml': fs.readFileSync('test-trait-3.raml', 'utf8'),
  'test-trait-4.raml': fs.readFileSync('test-trait-4.raml', 'utf8'),
};

console.log('Files loaded:');
Object.keys(files).forEach(f => console.log(`  ${f}`));
console.log('');

try {
  const result = convertRamlToOas(files, 'test-comment-in-library.raml');
  console.log('\n✅ Success! Libraries with inline comments were resolved correctly.');
  console.log('\nGenerated paths:');
  console.log(Object.keys(result.paths || {}).join('\n'));
} catch (error) {
  console.error('\n❌ Error:', error.message);
  process.exit(1);
}
