'use client';

import { useState } from 'react';
import FileUpload from '@/components/FileUpload';
import ConversionResult from '@/components/ConversionResult';

export default function Home() {
  const [converting, setConverting] = useState(false);
  const [result, setResult] = useState<{
    success: boolean;
    data?: any;
    error?: string;
  } | null>(null);

  const handleFileUpload = async (file: File) => {
    setConverting(true);
    setResult(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/convert', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        setResult({
          success: false,
          error: data.error || 'Conversion failed',
        });
      } else {
        setResult({
          success: true,
          data: data,
        });
      }
    } catch (error) {
      setResult({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      });
    } finally {
      setConverting(false);
    }
  };

  const handleReset = () => {
    setResult(null);
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
      <div className="max-w-5xl mx-auto">
        <header className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            RAML to OAS Converter
          </h1>
          <p className="text-lg text-gray-700">
            Upload your RAML ZIP file and convert it to OpenAPI Specification
          </p>
        </header>

        {!result ? (
          <FileUpload onUpload={handleFileUpload} isConverting={converting} />
        ) : (
          <ConversionResult result={result} onReset={handleReset} />
        )}

        <footer className="mt-16 text-center text-sm text-gray-600">
          <p>Supports RAML 0.8 and 1.0 with multi-file/folder references</p>
          <p className="mt-2">Converts to OpenAPI 3.0 specification</p>
        </footer>
      </div>
    </main>
  );
}
