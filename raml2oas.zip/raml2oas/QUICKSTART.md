# Quick Start Guide - RAML to OAS Converter

## 🎯 Your App is Ready!

The Next.js RAML to OAS converter is now running at: **http://localhost:3000**

## ✅ What's Built

### Features Implemented:
- ✅ **Modern Next.js 14 App** with TypeScript and Tailwind CSS
- ✅ **Drag & Drop Upload** - Upload ZIP files containing RAML projects
- ✅ **Multi-file Support** - Handles complex RAML projects with includes
- ✅ **Smart File Resolution** - Automatically finds and parses referenced files
- ✅ **RAML 0.8 & 1.0** - Full support for both RAML versions
- ✅ **OpenAPI 3.0 Output** - Converts to industry-standard OAS 3.0
- ✅ **Download Options** - Export as JSON or YAML
- ✅ **Copy to Clipboard** - Quick copy functionality
- ✅ **Error Handling** - Comprehensive error messages
- ✅ **Preview Output** - View converted OAS before downloading

## 🚀 How to Use

### Step 1: Prepare Your RAML ZIP File

Create a ZIP file with your RAML project:
```
my-api.zip
├── api.raml              # Main RAML file (or main.raml)
├── types/
│   ├── user.raml
│   └── product.raml
├── traits/
│   └── pageable.raml
└── examples/
    └── sample.json
```

**Important:** The main RAML file should be named `api.raml` or `main.raml` in the root of the ZIP.

### Step 2: Upload and Convert

1. Open http://localhost:3000 in your browser
2. Drag & drop your ZIP file or click to browse
3. Click "Convert to OAS"
4. Wait for the conversion (usually takes 1-3 seconds)

### Step 3: Download Results

1. Choose your preferred format (JSON or YAML)
2. Click "Download OAS" to save the file
3. Or click "Copy to Clipboard" for immediate use

## 📁 Project Structure

```
raml-to-oas/
├── app/
│   ├── api/convert/route.ts    # Conversion API endpoint
│   ├── layout.tsx              # Root layout
│   ├── page.tsx                # Main page
│   └── globals.css             # Tailwind styles
├── components/
│   ├── FileUpload.tsx          # Upload UI
│   └── ConversionResult.tsx    # Results display
├── lib/
│   └── converter.ts            # RAML to OAS conversion logic
├── public/                     # Static assets
├── package.json
├── tsconfig.json
├── tailwind.config.js
├── next.config.js
├── README.md                   # Full documentation
├── TESTING.md                  # Sample RAML examples
└── QUICKSTART.md              # This file
```

## 🧪 Testing with Sample RAML

Create a simple test file (`api.raml`):

```yaml
#%RAML 1.0
title: Test API
version: v1
baseUri: https://api.example.com/{version}

/users:
  get:
    description: Get all users
    responses:
      200:
        body:
          application/json:
            type: object
            properties:
              users:
                type: array
  post:
    description: Create a user
    body:
      application/json:
        type: object
        properties:
          name:
            type: string
          email:
            type: string
    responses:
      201:
        description: User created
```

1. Save this as `api.raml`
2. ZIP the file
3. Upload to the converter
4. View the OpenAPI 3.0 output!

## 🛠️ Development Commands

```bash
# Start development server (already running)
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Run linter
npm run lint
```

## 🔧 Supported RAML Features

### ✅ Fully Supported:
- Resources and nested resources
- Methods (GET, POST, PUT, DELETE, etc.)
- Query parameters and headers
- Request and response bodies
- Data types and schemas
- Includes (!include syntax)
- Resource types and traits
- Security schemes
- Examples and descriptions
- Base URI and version
- Multiple content types

### 📝 Conversion Details:
- **RAML Types** → **OAS Components/Schemas**
- **RAML Resources** → **OAS Paths**
- **RAML Methods** → **OAS Operations**
- **RAML Security** → **OAS Security Schemes**
- **RAML Includes** → Resolved inline in OAS

## 🐛 Troubleshooting

### Issue: "No main RAML file found"
**Solution:** Ensure your ZIP has `api.raml` or `main.raml` in the root directory.

### Issue: "File not found" during parsing
**Solution:** Check that all `!include` paths are relative and files exist in the ZIP.

### Issue: "RAML parsing errors"
**Solution:** Validate your RAML syntax. Use a RAML validator before converting.

### Issue: Conversion takes too long
**Solution:** Large projects (100+ files) may take 5-10 seconds. This is normal.

## 📚 Next Steps

### For Production Deployment:

1. **Build the app:**
   ```bash
   npm run build
   ```

2. **Deploy to Vercel (recommended):**
   ```bash
   npm install -g vercel
   vercel
   ```

3. **Or deploy to any Node.js host:**
   - Build with `npm run build`
   - Start with `npm start`
   - Ensure Node.js 18+ is available

### For Customization:

- **Change styling:** Edit `app/globals.css` and `tailwind.config.js`
- **Add features:** Modify components in `components/`
- **Enhance conversion:** Update `lib/converter.ts`
- **Add validation:** Extend the API route in `app/api/convert/route.ts`

## 💡 Tips

1. **Large Files:** For RAML projects over 50MB, increase Node.js memory:
   ```bash
   NODE_OPTIONS="--max-old-space-size=4096" npm run dev
   ```

2. **Security:** In production, add file size limits in `next.config.js`:
   ```js
   api: {
     bodyParser: {
       sizeLimit: '10mb',
     },
   }
   ```

3. **Performance:** The app uses in-memory processing. For very large conversions, consider adding a job queue.

## 📞 Support

- Check `README.md` for detailed documentation
- See `TESTING.md` for sample RAML files
- Review `lib/converter.ts` for conversion logic

## 🎉 Success!

Your RAML to OAS converter is fully operational! Start converting your RAML specifications now.

**Access the app:** http://localhost:3000

---

Built with ❤️ using Next.js, TypeScript, and raml-1-parser
