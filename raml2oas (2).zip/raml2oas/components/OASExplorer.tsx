'use client';

import { useState } from 'react';
import EndpointDetails from './EndpointDetails';

interface OASExplorerProps {
  exploration: any;
  onReset: () => void;
  onBack: () => void;
}

export default function OASExplorer({ exploration, onReset, onBack }: OASExplorerProps) {
  const [selectedEndpoint, setSelectedEndpoint] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [methodFilter, setMethodFilter] = useState<string>('ALL');

  if (selectedEndpoint) {
    return <EndpointDetails endpoint={selectedEndpoint} onBack={() => setSelectedEndpoint(null)} />;
  }

  const methods = ['ALL', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'];
  
  const filteredEndpoints = exploration.endpoints.filter((endpoint: any) => {
    const matchesSearch = endpoint.path.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         endpoint.summary?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         endpoint.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesMethod = methodFilter === 'ALL' || endpoint.method === methodFilter;
    return matchesSearch && matchesMethod;
  });

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-[#00AEEF] to-[#0082b9] rounded-lg shadow-lg p-8 text-white">
        <h2 className="text-3xl font-bold mb-2">{exploration.title}</h2>
        <p className="text-white opacity-90">Version: {exploration.version}</p>
        {exploration.description && (
          <p className="text-white opacity-90 mt-2">{exploration.description}</p>
        )}
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-4">
            <button
              onClick={onBack}
              className="text-[#00AEEF] hover:text-[#0082b9] font-semibold text-sm flex items-center gap-2"
            >
              Back
            </button>
            <h3 className="text-xl font-bold text-gray-800">
              API Endpoints ({filteredEndpoints.length})
            </h3>
          </div>
          <button
            onClick={onReset}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-semibold text-sm"
          >
            Upload New File
          </button>
        </div>

        <div className="mb-6 space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Search Endpoints:
            </label>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by path, summary, or description..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#00AEEF] focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Filter by Method:
            </label>
            <div className="flex flex-wrap gap-2">
              {methods.map((method) => (
                <button
                  key={method}
                  onClick={() => setMethodFilter(method)}
                  className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
                    methodFilter === method
                      ? 'bg-[#00AEEF] text-white shadow-md'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {method}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-3">
          {filteredEndpoints.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No endpoints found matching your filters</p>
          ) : (
            filteredEndpoints.map((endpoint: any, idx: number) => (
              <div
                key={idx}
                onClick={() => setSelectedEndpoint(endpoint)}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md hover:border-[#00AEEF] transition-all cursor-pointer"
              >
                <div className="flex items-center gap-3 mb-2">
                  <span className={`px-3 py-1 rounded font-semibold text-sm ${
                    endpoint.method === 'GET' ? 'bg-[#e6f7fd] text-[#00AEEF]' :
                    endpoint.method === 'POST' ? 'bg-green-100 text-green-800' :
                    endpoint.method === 'PUT' ? 'bg-orange-100 text-orange-800' :
                    endpoint.method === 'PATCH' ? 'bg-yellow-100 text-yellow-800' :
                    endpoint.method === 'DELETE' ? 'bg-red-100 text-red-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {endpoint.method}
                  </span>
                  <code className="text-gray-800 font-mono text-sm">{endpoint.path}</code>
                </div>
                {endpoint.summary && (
                  <p className="text-gray-700 text-sm font-semibold">{endpoint.summary}</p>
                )}
                {endpoint.description && (
                  <p className="text-gray-600 text-sm mt-1">{endpoint.description}</p>
                )}
                <div className="mt-3 flex gap-4 text-xs text-gray-500">
                  {endpoint.parameters.length > 0 && (
                    <span>Parameters: {endpoint.parameters.length}</span>
                  )}
                  {endpoint.requestBody && (
                    <span>Request Body: {endpoint.requestBody.fields.length} fields</span>
                  )}
                  {Object.keys(endpoint.responses).length > 0 && (
                    <span>Responses: {Object.keys(endpoint.responses).length}</span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
