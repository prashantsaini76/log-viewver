'use client';

import { useState } from 'react';

interface ConversionResultProps {
  result: {
    success: boolean;
    data?: any;
    raml?: string;
    oas?: string;
    originalFile?: string;
    error?: string;
  };
  onReset: () => void;
}

export default function ConversionResult({ result, onReset }: ConversionResultProps) {
  const [downloadFormat, setDownloadFormat] = useState<'json' | 'yaml'>('json');
  const [copied, setCopied] = useState(false);
  
  // Determine if this is a RAML flattening, OAS flattening, or OAS conversion result
  const isRamlFlattening = !!result.raml;
  const isOasFlattening = !!result.oas;
  const isConversion = !!result.data;

  const handleDownload = () => {
    if (!result.success) return;

    let content: string;
    let filename: string;

    if (isRamlFlattening) {
      content = result.raml!;
      filename = 'api.raml';
    } else if (isOasFlattening) {
      content = result.oas!;
      filename = 'openapi.yaml';
    } else if (result.data) {
      content = downloadFormat === 'json' 
        ? JSON.stringify(result.data.oas, null, 2)
        : result.data.yaml || JSON.stringify(result.data.oas, null, 2);
      filename = `openapi.${downloadFormat}`;
    } else {
      return;
    }

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopy = async () => {
    if (!result.success) return;

    let content: string;

    if (isRamlFlattening) {
      content = result.raml!;
    } else if (isOasFlattening) {
      content = result.oas!;
    } else if (result.data) {
      content = downloadFormat === 'json'
        ? JSON.stringify(result.data.oas, null, 2)
        : result.data.yaml || JSON.stringify(result.data.oas, null, 2);
    } else {
      return;
    }

    await navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!result.success) {
    return (
      <div className="bg-white rounded-2xl shadow-2xl p-8 md:p-12">
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <svg
              className="w-20 h-20 text-red-500"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Conversion Failed
          </h2>
          <p className="text-red-600 mb-8 text-lg">
            {result.error || 'An unknown error occurred'}
          </p>
          <button
            onClick={onReset}
            className="bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 px-8 rounded-lg transition-colors duration-200"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-2xl p-8 md:p-12">
      <div className="text-center mb-8">
        <div className="flex justify-center mb-6">
          <svg
            className="w-20 h-20 text-green-500"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">
          {isRamlFlattening ? 'RAML Flattening Successful!' : isOasFlattening ? 'OAS Flattening Successful!' : 'Conversion Successful!'}
        </h2>
        <p className="text-gray-600">
          {isRamlFlattening 
            ? 'Your RAML files have been consolidated into a single file'
            : isOasFlattening
            ? 'Your OpenAPI files have been consolidated into a single file'
            : 'Your RAML has been converted to OpenAPI 3.0'
          }
        </p>
      </div>

      {result.data?.filesProcessed && (
        <div className="mb-6 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Files processed:</span>{' '}
            {result.data.filesProcessed}
          </p>
        </div>
      )}

      {result.originalFile && (
        <div className="mb-6 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Original file:</span>{' '}
            {result.originalFile}
          </p>
        </div>
      )}

      <div className="space-y-4">
        {isConversion && (
          <div className="flex items-center justify-between mb-4">
            <label className="text-sm font-semibold text-gray-700">
              Download Format:
            </label>
            <div className="flex gap-2">
              <button
                onClick={() => setDownloadFormat('json')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  downloadFormat === 'json'
                    ? 'bg-primary-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                JSON
              </button>
              <button
                onClick={() => setDownloadFormat('yaml')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  downloadFormat === 'yaml'
                    ? 'bg-primary-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                YAML
              </button>
            </div>
          </div>
        )}

        <div className="flex gap-4">
          <button
            onClick={handleDownload}
            className="flex-1 bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 shadow-lg hover:shadow-xl"
          >
            {isRamlFlattening ? 'Download RAML' : isOasFlattening ? 'Download OAS' : 'Download OAS'}
          </button>
          <button
            onClick={handleCopy}
            className="flex-1 bg-gray-600 hover:bg-gray-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 shadow-lg hover:shadow-xl"
          >
            {copied ? 'Copied!' : 'Copy to Clipboard'}
          </button>
        </div>

        <button
          onClick={onReset}
          className="w-full bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold py-3 px-6 rounded-lg transition-colors duration-200"
        >
          Convert Another File
        </button>
      </div>

      <div className="mt-8 p-4 bg-gray-50 rounded-lg max-h-96 overflow-auto">
        <h3 className="text-sm font-semibold text-gray-700 mb-2">Preview:</h3>
        <pre className="text-xs text-gray-600 whitespace-pre-wrap">
          {isRamlFlattening 
            ? (result.raml?.substring(0, 1000) || '') + '...'
            : isOasFlattening
            ? (result.oas?.substring(0, 1000) || '') + '...'
            : (result.data?.oas ? JSON.stringify(result.data.oas, null, 2).substring(0, 1000) + '...' : '')
          }
        </pre>
      </div>
    </div>
  );
}
