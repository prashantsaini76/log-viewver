import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'RAML to OAS Converter',
  description: 'Convert RAML specifications to OpenAPI Specification (OAS)',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
