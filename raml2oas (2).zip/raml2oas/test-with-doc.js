const fs = require('fs');
const { convertRamlToOas } = require('./lib/converter.ts');

async function testWithDocumentation() {
  console.log('Testing API with documentation include...\n');
  
  const files = {
    'test-with-doc.raml': fs.readFileSync('test-with-doc.raml', 'utf-8'),
    'docs/doc-api.md': `# Welcome
    
API Purpose: This API forms part of the system...

Business Owner: someone@example.com

Tech Owner: another@example.com`,
  };
  
  console.log('Files loaded:');
  Object.keys(files).forEach(f => console.log(`  ${f}`));
  console.log('');
  
  try {
    const result = await convertRamlToOas(files, 'test-with-doc.raml');
    console.log('\n✅ Conversion successful!\n');
    console.log('The documentation file was skipped, and conversion completed.');
    console.log('\nOpenAPI paths:', Object.keys(result.oas.paths));
  } catch (error) {
    console.error('\n❌ Conversion failed:');
    console.error(error.message);
  }
}

testWithDocumentation();
