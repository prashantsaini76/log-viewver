'use client';

import { useState } from 'react';
import FileUpload from '@/components/FileUpload';
import ConversionResult from '@/components/ConversionResult';
import RegexTester from '@/components/RegexTester';
import OASExplorer from '@/components/OASExplorer';

type ConversionMode = 'oas' | 'validate' | 'regex' | 'explore';

export default function Home() {
  const [converting, setConverting] = useState(false);
  const [mode, setMode] = useState<ConversionMode>('oas');
  const [result, setResult] = useState<{
    success: boolean;
    data?: any;
    validation?: {
      valid: boolean;
      errors: any[];
    };
    exploration?: any;
    error?: string;
  } | null>(null);
  const [savedValidationData, setSavedValidationData] = useState<any>(null);
  const [savedFile, setSavedFile] = useState<File | null>(null);

  const handleFileUpload = async (file: File, validationData?: any) => {
    setConverting(true);
    setResult(null);

    // Save file and validation data for when user wants to go back
    setSavedFile(file);
    if (validationData) {
      setSavedValidationData(validationData);
    }

    try {
      const formData = new FormData();
      formData.append('file', file);
      
      if (validationData) {
        formData.append('payload', JSON.stringify(validationData.payload));
        formData.append('path', validationData.path);
        formData.append('method', validationData.method);
        formData.append('type', validationData.type);
        if (validationData.headers) {
          formData.append('headers', JSON.stringify(validationData.headers));
        }
      }

      let endpoint = '/api/convert';
      if (mode === 'validate') {
        endpoint = '/api/validate';
      } else if (mode === 'explore') {
        endpoint = '/api/explore';
      }
      
      // Add timeout to prevent hanging
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
      
      const response = await fetch(endpoint, {
        method: 'POST',
        body: formData,
        signal: controller.signal,
      });
      
      clearTimeout(timeoutId);

      const data = await response.json();

      if (!response.ok) {
        setResult({
          success: false,
          error: data.error || 'Operation failed',
        });
      } else {
        // Handle different response structures
        if (mode === 'validate') {
          setResult({
            success: true,
            validation: data.validation,
          });
        } else if (mode === 'explore') {
          setResult({
            success: true,
            exploration: data.exploration,
          });
        } else {
          setResult({
            success: true,
            data: data,
          });
        }
      }
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        setResult({
          success: false,
          error: 'Request timeout - validation took too long. This might indicate an infinite loop in $ref resolution.',
        });
      } else {
        setResult({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error occurred',
        });
      }
    } finally {
      setConverting(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setSavedValidationData(null);
    setSavedFile(null);
  };

  const handleBackToValidation = () => {
    setResult(null);
    // Keep savedValidationData and savedFile so FileUpload can restore everything
  };

  const handleBackToExplore = () => {
    setResult(null);
    // Keep savedFile so FileUpload can restore the uploaded file
  };

  return (
    <main className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-5xl mx-auto">
        <header className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            API Specification Platform
          </h1>
          <p className="text-lg text-gray-600">
            Professional tool for API specification conversion, validation, and exploration
          </p>
        </header>

        {!result && (
          <div className="mb-8 flex justify-center gap-3 flex-wrap">
            <button
              onClick={() => setMode('oas')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                mode === 'oas'
                  ? 'bg-[#00AEEF] text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200'
              }`}
            >
              RAML to OAS
            </button>
            <button
              onClick={() => setMode('validate')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                mode === 'validate'
                  ? 'bg-[#00AEEF] text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200'
              }`}
            >
              Validate Payload
            </button>
            <button
              onClick={() => setMode('explore')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                mode === 'explore'
                  ? 'bg-[#00AEEF] text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200'
              }`}
            >
              Explore OAS
            </button>
            <button
              onClick={() => setMode('regex')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                mode === 'regex'
                  ? 'bg-[#00AEEF] text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200'
              }`}
            >
              Regex Tester
            </button>
          </div>
        )}

        {mode === 'regex' ? (
          <RegexTester />
        ) : result && result.exploration ? (
          <OASExplorer exploration={result.exploration} onReset={handleReset} onBack={handleBackToExplore} />
        ) : !result ? (
          <FileUpload 
            onUpload={handleFileUpload} 
            isConverting={converting} 
            mode={mode as 'oas' | 'validate' | 'explore'} 
            savedValidationData={savedValidationData}
            savedFile={savedFile}
          />
        ) : (
          <ConversionResult 
            result={result} 
            onReset={handleReset}
            onBack={mode === 'validate' ? handleBackToValidation : undefined}
            mode={mode as 'oas' | 'validate'}
          />
        )}

        <footer className="mt-16 text-center text-sm text-gray-500">
          <p>Supports RAML 0.8/1.0 and OpenAPI 3.0 with multi-file/folder references</p>
          <p className="mt-2">
            {mode === 'oas' 
              ? 'Converts RAML to OpenAPI 3.0 specification'
              : mode === 'validate'
              ? 'Validates request/response payloads against OpenAPI specification'
              : mode === 'explore'
              ? 'Explore OpenAPI specifications and view endpoint details'
              : 'Test and debug regular expressions with live matching'
            }
          </p>
        </footer>
      </div>
    </main>
  );
}
