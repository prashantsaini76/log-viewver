'use client';

import { useState } from 'react';
import FileUpload from '@/components/FileUpload';
import ConversionResult from '@/components/ConversionResult';

type ConversionMode = 'oas' | 'validate';

export default function Home() {
  const [converting, setConverting] = useState(false);
  const [mode, setMode] = useState<ConversionMode>('oas');
  const [result, setResult] = useState<{
    success: boolean;
    data?: any;
    validation?: {
      valid: boolean;
      errors: any[];
    };
    error?: string;
  } | null>(null);
  const [savedValidationData, setSavedValidationData] = useState<any>(null);
  const [savedFile, setSavedFile] = useState<File | null>(null);

  const handleFileUpload = async (file: File, validationData?: any) => {
    setConverting(true);
    setResult(null);

    // Save file and validation data for when user wants to go back
    setSavedFile(file);
    if (validationData) {
      setSavedValidationData(validationData);
    }

    try {
      const formData = new FormData();
      formData.append('file', file);
      
      if (validationData) {
        formData.append('payload', JSON.stringify(validationData.payload));
        formData.append('path', validationData.path);
        formData.append('method', validationData.method);
        formData.append('type', validationData.type);
      }

      let endpoint = '/api/convert';
      if (mode === 'validate') {
        endpoint = '/api/validate';
      }
      
      // Add timeout to prevent hanging
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
      
      const response = await fetch(endpoint, {
        method: 'POST',
        body: formData,
        signal: controller.signal,
      });
      
      clearTimeout(timeoutId);

      const data = await response.json();

      if (!response.ok) {
        setResult({
          success: false,
          error: data.error || 'Conversion failed',
        });
      } else {
        // Handle different response structures
        if (mode === 'validate') {
          setResult({
            success: true,
            validation: data.validation,
          });
        } else {
          setResult({
            success: true,
            data: data,
          });
        }
      }
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        setResult({
          success: false,
          error: 'Request timeout - validation took too long. This might indicate an infinite loop in $ref resolution.',
        });
      } else {
        setResult({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error occurred',
        });
      }
    } finally {
      setConverting(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setSavedValidationData(null);
    setSavedFile(null);
  };

  const handleBackToValidation = () => {
    setResult(null);
    // Keep savedValidationData and savedFile so FileUpload can restore everything
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
      <div className="max-w-5xl mx-auto">
        <header className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            RAML to OAS Converter
          </h1>
          <p className="text-lg text-gray-700">
            Convert RAML to OpenAPI or validate request/response payloads against OAS
          </p>
        </header>

        {!result && (
          <div className="mb-8 flex justify-center gap-3 flex-wrap">
            <button
              onClick={() => setMode('oas')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                mode === 'oas'
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              RAML → OAS
            </button>
            <button
              onClick={() => setMode('validate')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                mode === 'validate'
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Validate Payload
            </button>
          </div>
        )}

        {!result ? (
          <FileUpload 
            onUpload={handleFileUpload} 
            isConverting={converting} 
            mode={mode} 
            savedValidationData={savedValidationData}
            savedFile={savedFile}
          />
        ) : (
          <ConversionResult 
            result={result} 
            onReset={handleReset}
            onBack={mode === 'validate' ? handleBackToValidation : undefined}
            mode={mode}
          />
        )}

        <footer className="mt-16 text-center text-sm text-gray-600">
          <p>Supports RAML 0.8/1.0 and OpenAPI 3.0 with multi-file/folder references</p>
          <p className="mt-2">
            {mode === 'oas' 
              ? 'Converts RAML to OpenAPI 3.0 specification'
              : 'Validates request/response payloads against OpenAPI specification'
            }
          </p>
        </footer>
      </div>
    </main>
  );
}
