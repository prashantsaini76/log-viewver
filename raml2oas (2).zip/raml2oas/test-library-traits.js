const fs = require('fs');
const { convertRamlToOas } = require('./lib/converter.ts');

async function testLibraryTraits() {
  console.log('Testing library with trait includes...\n');
  
  const files = {
    'test-library-traits.raml': fs.readFileSync('test-library-traits.raml', 'utf-8'),
    'test-library-traits-lib.raml': fs.readFileSync('test-library-traits-lib.raml', 'utf-8'),
    'test-trait-cacheable.raml': fs.readFileSync('test-trait-cacheable.raml', 'utf-8'),
    'test-trait-not-cacheable.raml': fs.readFileSync('test-trait-not-cacheable.raml', 'utf-8'),
    'test-trait-3.raml': fs.readFileSync('test-trait-3.raml', 'utf-8'),
    'test-trait-4.raml': fs.readFileSync('test-trait-4.raml', 'utf-8'),
  };
  
  console.log('Files loaded:');
  Object.keys(files).forEach(f => console.log(`  ${f}`));
  console.log('');
  
  try {
    const result = await convertRamlToOas(files, 'test-library-traits.raml');
    console.log('\n✅ Conversion successful!\n');
    console.log('OpenAPI Spec:');
    console.log(JSON.stringify(result, null, 2));
  } catch (error) {
    console.error('\n❌ Conversion failed:');
    console.error(error.message);
    if (error.stack) {
      console.error('\nStack trace:');
      console.error(error.stack);
    }
  }
}

testLibraryTraits();
