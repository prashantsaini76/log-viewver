const fs = require('fs');
const { convertRamlToOas } = require('./lib/converter.ts');

async function test() {
  console.log('Testing nested includes in library types...\n');

  const files = {
    'test-nested-includes.raml': fs.readFileSync('test-nested-includes.raml', 'utf8'),
    'test-lib-customer-response.raml': fs.readFileSync('test-lib-customer-response.raml', 'utf8'),
    'test-type-response.raml': fs.readFileSync('test-type-response.raml', 'utf8'),
    'test-type-get-details.raml': fs.readFileSync('test-type-get-details.raml', 'utf8')
  };

  console.log('Files loaded:');
  Object.keys(files).forEach(f => console.log(`  ${f}`));
  console.log('');

  try {
    const result = await convertRamlToOas(files, 'test-nested-includes.raml');
    console.log('\n✅ Conversion successful!');
    
    const getOperation = result.oas.paths?.['/customers/{contractReference}']?.get;
    if (getOperation) {
      const response200 = getOperation.responses?.['200'];
      if (response200 && response200.content) {
        console.log('\n✅ Response 200 has content!');
        console.log('\nResponse 200 Schema:');
        console.log(JSON.stringify(response200.content['application/json']?.schema, null, 2));
      } else {
        console.log('\n❌ WARNING: Response 200 has NO content!');
        console.log('Response 200:', JSON.stringify(response200, null, 2));
      }
    }
  } catch (error) {
    console.error('\n❌ Error:', error.message);
    process.exit(1);
  }
}

test();
