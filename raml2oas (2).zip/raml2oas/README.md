# RAML to OAS Converter

A modern Next.js application for converting RAML (RESTful API Modeling Language) specifications to OpenAPI Specification (OAS) 3.0, and flattening multi-file RAML projects into single files.

## ✨ Features

### Core Capabilities
- 🔄 **Dual Mode Operation**
  - **RAML → OAS**: Convert to OpenAPI 3.0 with enterprise enhancements
  - **RAML → Flattened RAML**: Consolidate multi-file projects into single file

### RAML to OAS Conversion
- 🚀 **Next.js 14** with App Router
- 📦 **ZIP File Upload** - Drag & drop or click to upload
- 🔄 **Multi-file Support** - Handles RAML projects with multiple folders and file references
- 📋 **RAML 0.8 & 1.0** - Full support for both RAML versions
- 🎯 **OpenAPI 3.0** - Converts to latest OAS specification
- 💾 **Multiple Formats** - Download as JSON or YAML
- ✅ **Enterprise Enhancements** - Meets Barclays API governance standards
- � **Production Ready** - Comprehensive validation and error handling

### RAML Flattening (NEW)
- 📄 **Single File Output** - Consolidate all RAML files into one
- 🔗 **Include Resolution** - Resolves all `!include` directives
- 📚 **Library Inlining** - Expands library types with namespace preservation
- �🎨 **Structure Preservation** - Maintains API hierarchy and relationships
- 🚀 **Simplified Sharing** - Easy distribution without folder structure

### UI & UX
- 🎨 **Modern UI** - Clean, responsive design with Tailwind CSS
- ⚡ **Fast Conversion** - Server-side processing with optimized parsing
- 📊 **Preview & Download** - View results and download immediately
- 🔄 **Mode Toggle** - Easy switching between conversion modes

## 🛠️ Installation

### Prerequisites

- Node.js 18+ or 20+
- npm, yarn, or pnpm

### Setup

1. Clone the repository:
```bash
git clone <your-repo-url>
cd raml-to-oas
```

2. Install dependencies:
```bash
npm install
# or
yarn install
# or
pnpm install
```

3. Run the development server:
```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## 🚀 Usage

The application supports two conversion modes accessible via a toggle at the top of the page.

### Mode 1: RAML to OAS Conversion

1. **Select Mode:**
   - Click "Convert to OAS" button

2. **Prepare your RAML files:**
   - Create a ZIP file containing your RAML project
   - The main RAML file should be named `api.raml` or `main.raml` in the root
   - Include all referenced files (includes, traits, types, examples, etc.)

3. **Upload and Convert:**
   - Drag and drop your ZIP file onto the upload area
   - Or click to browse and select your ZIP file
   - Wait for the conversion to complete

4. **Download Results:**
   - Choose between JSON or YAML format
   - Click "Download OAS" to save the converted specification
   - Or copy to clipboard for immediate use

### Mode 2: RAML Flattening (NEW)

1. **Select Mode:**
   - Click "Flatten RAML" button

2. **Prepare your RAML files:**
   - Create a ZIP file containing your multi-file RAML project
   - Ensure all includes and library references are present

3. **Upload and Flatten:**
   - Drag and drop your ZIP file onto the upload area
   - Or click to browse and select your ZIP file
   - Wait for the flattening to complete

4. **Download Result:**
   - Click "Download RAML" to save the consolidated `api.raml` file
   - Or copy to clipboard for immediate use

### When to Use Each Mode

**Convert to OAS** - Best for:
- ✅ Generating OpenAPI documentation
- ✅ Using OAS-based tools (Swagger UI, Postman, code generators)
- ✅ Implementing APIs with OAS-native frameworks
- ✅ Meeting OpenAPI governance and compliance requirements

**Flatten RAML** - Best for:
- ✅ Sharing RAML without complex folder structure
- ✅ Using with tools that don't support multi-file RAML
- ✅ Creating standalone API documentation
- ✅ Simplifying RAML for distribution, embedding, or version control

### Example RAML Project Structure

```
my-api.zip
├── api.raml              # Main RAML file
├── libraries/
│   ├── common-types.raml
│   └── error-types.raml
├── resources/
│   ├── users/
│   │   └── users.raml
│   └── orders/
│       └── orders.raml
├── traits/
│   ├── pageable.raml
│   └── secured.raml
└── examples/
    ├── user-example.json
    └── order-example.json
```

## 🏗️ Project Structure

```
raml-to-oas/
├── app/
│   ├── api/
│   │   ├── convert/
│   │   │   └── route.ts       # OAS conversion endpoint
│   │   └── flatten/
│   │       └── route.ts       # RAML flattening endpoint
│   ├── layout.tsx             # Root layout
│   ├── page.tsx               # Home page with mode toggle
│   └── globals.css            # Global styles
├── components/
│   ├── FileUpload.tsx         # File upload component
│   └── ConversionResult.tsx   # Results display (both modes)
├── lib/
│   └── converter.ts           # Conversion & flattening logic (2200+ lines)
├── raml-sample-api/           # Sample multi-file RAML project
│   ├── api.raml
│   ├── libraries/
│   ├── resources/
│   ├── traits/
│   └── examples/
├── BUILD_SUMMARY.md           # Development history
├── FEATURE_SUMMARY.md         # Complete feature list
├── RAML_FLATTENING.md        # Flattening feature docs
├── QUICKSTART.md             # Quick start guide
├── TESTING.md                # Testing instructions
├── README.md                 # This file
├── public/                   # Static assets
├── package.json
├── tsconfig.json
├── tailwind.config.js
└── next.config.js
```

## 🔧 Technology Stack

- **Framework:** Next.js 14 with App Router
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **RAML Parser:** raml-1-parser
- **ZIP Handling:** JSZip
- **YAML Processing:** js-yaml

## 📝 Supported RAML Features

### ✅ Fully Supported

- RAML 0.8 and 1.0 specifications
- Multi-file projects with includes
- Resource types and traits
- Data types and schemas
- Query parameters and headers
- Request and response bodies
- Security schemes (OAuth 2.0, Basic Auth, API Keys)
- Examples and descriptions
- Nested resources
- Base URI and protocols

### ⚠️ Partial Support

- Some advanced RAML 1.0 features may require manual review
- Complex annotations may not convert directly

## 🔍 API Reference

### POST /api/convert

Converts a RAML ZIP file to OpenAPI Specification.

**Request:**
- Content-Type: `multipart/form-data`
- Body: ZIP file containing RAML project

**Response:**
```json
{
  "success": true,
  "oas": { /* OpenAPI 3.0 specification */ },
  "yaml": "openapi: 3.0.0\n...",
  "filesProcessed": 5,
  "mainFile": "api.raml"
}
```

**Error Response:**
```json
{
  "error": "Error message",
  "details": "Stack trace (in development)"
}
```

## 🐛 Troubleshooting

### Common Issues

**"No main RAML file found"**
- Ensure your ZIP contains `api.raml` or `main.raml` in the root directory
- Or any `.raml` file in the root directory

**"RAML parsing errors"**
- Check that all included files are present in the ZIP
- Verify RAML syntax is valid
- Ensure file paths in includes match the actual file structure

**"File not found" during conversion**
- Make sure all referenced files use relative paths
- Check that file names match exactly (case-sensitive)

## 📦 Building for Production

```bash
# Build the application
npm run build

# Start production server
npm start
```

## 🧪 Development

```bash
# Run development server with hot reload
npm run dev

# Run linter
npm run lint

# Type check
npx tsc --noEmit
```

## 📄 License

MIT License - feel free to use this project for personal or commercial purposes.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 🔗 Resources

- [RAML Specification](https://raml.org/)
- [OpenAPI Specification](https://swagger.io/specification/)
- [Next.js Documentation](https://nextjs.org/docs)

## 📧 Support

If you encounter any issues or have questions, please open an issue on GitHub.

---

Built with ❤️ using Next.js and TypeScript
