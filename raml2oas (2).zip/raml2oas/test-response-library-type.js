const fs = require('fs');
const { convertRamlToOas } = require('./lib/converter.ts');

async function test() {
  console.log('Testing response with library type reference...\n');

  const files = {
    'test-response-library-type.raml': fs.readFileSync('test-response-library-type.raml', 'utf8'),
    'test-local-types-lib.raml': fs.readFileSync('test-local-types-lib.raml', 'utf8')
  };

  console.log('Files loaded:');
  Object.keys(files).forEach(f => console.log(`  ${f}`));
  console.log('');

  try {
    const result = await convertRamlToOas(files, 'test-response-library-type.raml');
    console.log('\n✅ Conversion successful!');
    
    // Check if the response schema is expanded
    const getOperation = result.oas.paths?.['/customers/{contractReference}']?.get;
    if (getOperation) {
      console.log('\n=== GET Operation ===');
      console.log(JSON.stringify(getOperation, null, 2));
      
      const response200 = getOperation.responses?.['200'];
      if (response200 && response200.content) {
        console.log('\n✅ Response 200 has content!');
        console.log('\nResponse 200 Schema:');
        console.log(JSON.stringify(response200.content['application/json']?.schema, null, 2));
      } else {
        console.log('\n❌ WARNING: Response 200 has NO content!');
        console.log('Response 200:', JSON.stringify(response200, null, 2));
      }
    } else {
      console.log('\n❌ WARNING: GET operation not found!');
    }
  } catch (error) {
    console.error('\n❌ Error:', error.message);
    if (error.stack) {
      console.error('\nStack trace:');
      console.error(error.stack);
    }
    process.exit(1);
  }
}

test();
