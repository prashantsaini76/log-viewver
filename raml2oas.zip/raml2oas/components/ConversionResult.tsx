'use client';

import { useState } from 'react';

interface ConversionResultProps {
  result: {
    success: boolean;
    data?: any;
    validation?: {
      valid: boolean;
      errors: any[];
    };
    error?: string;
  };
  onReset: () => void;
  onBack?: () => void;
  mode?: 'oas' | 'validate';
}

export default function ConversionResult({ result, onReset, onBack, mode }: ConversionResultProps) {
  const [downloadFormat, setDownloadFormat] = useState<'json' | 'yaml'>('json');
  const [copied, setCopied] = useState(false);
  
  // Determine if this is a validation result or OAS conversion
  const isValidation = !!result.validation;
  const isConversion = !!result.data;

  const handleDownload = () => {
    if (!result.success || !isConversion || !result.data) return;

    const content = downloadFormat === 'json' 
      ? JSON.stringify(result.data.oas, null, 2)
      : result.data.yaml || JSON.stringify(result.data.oas, null, 2);
    const filename = `openapi.${downloadFormat}`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopy = async () => {
    if (!result.success || !isConversion || !result.data) return;

    const content = downloadFormat === 'json'
      ? JSON.stringify(result.data.oas, null, 2)
      : result.data.yaml || JSON.stringify(result.data.oas, null, 2);

    await navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!result.success) {
    return (
      <div className="bg-white rounded-2xl shadow-2xl p-8 md:p-12">
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <svg
              className="w-20 h-20 text-red-500"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Conversion Failed
          </h2>
          <p className="text-red-600 mb-8 text-lg">
            {result.error || 'An unknown error occurred'}
          </p>
          <button
            onClick={onReset}
            className="bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 px-8 rounded-lg transition-colors duration-200"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-2xl p-8 md:p-12">
      <div className="text-center mb-8">
        {/* Back button for validation mode */}
        {isValidation && onBack && (
          <div className="flex justify-start mb-4">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors duration-200 group"
              title="Go back to validation form"
            >
              <svg
                className="w-5 h-5 transform group-hover:-translate-x-1 transition-transform duration-200"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
              <span className="font-medium">Back to Validation</span>
            </button>
          </div>
        )}
        
        <div className="flex justify-center mb-6">
          <svg
            className="w-20 h-20 text-green-500"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">
          {isValidation ? 'Validation Complete!' : 'Conversion Successful!'}
        </h2>
        <p className="text-gray-600">
          {isValidation
            ? result.validation?.valid 
              ? '✅ Payload is valid against the OAS schema'
              : `❌ Found ${result.validation?.errors?.length || 0} validation error(s)`
            : 'Your RAML has been converted to OpenAPI 3.0'
          }
        </p>
      </div>

      {/* Validation Results */}
      {isValidation && result.validation && (
        <>
          {result.validation.valid ? (
            <div className="mb-6 p-6 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-center space-x-3">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <div>
                  <h3 className="text-lg font-semibold text-green-800">Valid Payload</h3>
                  <p className="text-sm text-green-700">All fields match the OpenAPI schema definition</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="mb-6">
              <div className="p-4 bg-red-50 border border-red-200 rounded-t-lg">
                <h3 className="text-lg font-semibold text-red-800">
                  {result.validation.errors.length} Validation Error{result.validation.errors.length !== 1 ? 's' : ''}
                </h3>
                <p className="text-sm text-red-700">The following fields do not match the schema:</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Field</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Error</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Actual Value</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Expected</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {result.validation.errors.map((error: any, index: number) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="px-4 py-3 text-sm font-mono text-gray-900">{error.field}</td>
                        <td className="px-4 py-3 text-sm text-red-600">{error.message}</td>
                        <td className="px-4 py-3 text-sm font-mono text-gray-700">
                          {error.value !== undefined ? JSON.stringify(error.value) : 'undefined'}
                        </td>
                        <td className="px-4 py-3 text-sm font-mono text-gray-700">
                          {error.expected !== undefined ? JSON.stringify(error.expected) : '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {/* Conversion Stats */}
      {result.data?.filesProcessed && (
        <div className="mb-6 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Files processed:</span>{' '}
            {result.data.filesProcessed}
          </p>
        </div>
      )}

      {isConversion && result.data?.metadata?.originalFile && (
        <div className="mb-6 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Original file:</span>{' '}
            {result.data.metadata.originalFile}
          </p>
        </div>
      )}

      <div className="space-y-4">
        {isConversion && (
          <>
            <div className="flex items-center justify-between mb-4">
              <label className="text-sm font-semibold text-gray-700">
                Download Format:
              </label>
              <div className="flex gap-2">
                <button
                  onClick={() => setDownloadFormat('json')}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    downloadFormat === 'json'
                      ? 'bg-primary-600 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  JSON
                </button>
                <button
                  onClick={() => setDownloadFormat('yaml')}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    downloadFormat === 'yaml'
                      ? 'bg-primary-600 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  YAML
                </button>
              </div>
            </div>

            <div className="flex gap-4">
              <button
                onClick={handleDownload}
                className="flex-1 bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 shadow-lg hover:shadow-xl"
              >
                Download OAS
              </button>
              <button
                onClick={handleCopy}
                className="flex-1 bg-gray-600 hover:bg-gray-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 shadow-lg hover:shadow-xl"
              >
                {copied ? 'Copied!' : 'Copy to Clipboard'}
              </button>
            </div>

            <div className="mt-8 p-4 bg-gray-50 rounded-lg max-h-96 overflow-auto">
              <h3 className="text-sm font-semibold text-gray-700 mb-2">Preview:</h3>
              <pre className="text-xs text-gray-600 whitespace-pre-wrap">
                {result.data?.oas ? JSON.stringify(result.data.oas, null, 2).substring(0, 1000) + '...' : ''}
              </pre>
            </div>
          </>
        )}

        <button
          onClick={onReset}
          className="w-full bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold py-3 px-6 rounded-lg transition-colors duration-200"
        >
          {isValidation ? 'Validate Another Payload' : 'Convert Another File'}
        </button>
      </div>
    </div>
  );
}
