import { convertRamlToOas } from './lib/converter.ts';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function testTraits() {
  console.log('Testing trait includes...\n');
  
  // Read the test files
  const files = {
    'test-traits-api.raml': fs.readFileSync(path.join(__dirname, 'test-traits-api.raml'), 'utf-8'),
    'test-traits-lib.raml': fs.readFileSync(path.join(__dirname, 'test-traits-lib.raml'), 'utf-8'),
    'test-trait-simple.raml': fs.readFileSync(path.join(__dirname, 'test-trait-simple.raml'), 'utf-8'),
    'test-trait-with-tag.raml': fs.readFileSync(path.join(__dirname, 'test-trait-with-tag.raml'), 'utf-8'),
  };
  
  try {
    const result = await convertRamlToOas(files, 'test-traits-api.raml');
    console.log('✅ SUCCESS! Conversion completed.');
    console.log('\nGenerated OAS:\n');
    console.log(result.yaml);
    
    // Write output
    fs.writeFileSync('test-traits-output.yaml', result.yaml);
    console.log('\n📝 Output written to test-traits-output.yaml');
    
  } catch (error) {
    console.error('❌ FAILED:', error.message);
    console.error('\nCheck logs/converter-debug.log for details');
    console.error('Check logs/test-traits-lib.raml for the resolved library content');
    process.exit(1);
  }
}

testTraits();
