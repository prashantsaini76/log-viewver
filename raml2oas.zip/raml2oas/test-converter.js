const fs = require('fs');
const path = require('path');
const { convertRamlToOas } = require('./lib/converter.ts');

// Read all files from raml-sample-api folder
function readAllFiles(dir, baseDir = dir) {
  const files = {};
  const items = fs.readdirSync(dir, { withFileTypes: true });
  
  for (const item of items) {
    const fullPath = path.join(dir, item.name);
    const relativePath = path.relative(baseDir, fullPath).replace(/\\/g, '/');
    
    if (item.isDirectory()) {
      Object.assign(files, readAllFiles(fullPath, baseDir));
    } else {
      files[relativePath] = fs.readFileSync(fullPath, 'utf-8');
    }
  }
  
  return files;
}

async function test() {
  try {
    const ramlDir = path.join(__dirname, 'raml-sample-api');
    const files = readAllFiles(ramlDir);
    
    console.log('Files found:');
    console.log(Object.keys(files).join('\n'));
    console.log('\nConverting...\n');
    
    const result = await convertRamlToOas(files, 'api.raml');
    
    console.log('Conversion successful!');
    console.log('\nOpenAPI Spec:');
    console.log(JSON.stringify(result.oas, null, 2));
    
    // Write to file
    fs.writeFileSync(
      path.join(__dirname, 'output-oas.json'),
      JSON.stringify(result.oas, null, 2)
    );
    fs.writeFileSync(
      path.join(__dirname, 'output-oas.yaml'),
      result.yaml
    );
    
    console.log('\nFiles written: output-oas.json, output-oas.yaml');
  } catch (error) {
    console.error('Test failed:', error.message);
    console.error(error.stack);
  }
}

test();
