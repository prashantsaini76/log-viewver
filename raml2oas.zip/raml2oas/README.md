# RAML to OAS Converter with Payload Validation# RAML to OAS Converter with Payload Validation



A modern Next.js application for converting RAML (RESTful API Modeling Language) specifications to OpenAPI Specification (OAS) 3.0, and validating JSON payloads against OpenAPI schemas.A modern Next.js application for converting RAML (RESTful API Modeling Language) specifications to OpenAPI Specification (OAS) 3.0, and validating JSON payloads against OpenAPI schemas.



## ✨ Features## ✨ Features



### Core Capabilities### Core Capabilities

- 🔄 **Dual Mode Operation**- 🔄 **Dual Mode Operation**

  - **RAML → OAS**: Convert RAML to OpenAPI 3.0  - **RAML → OAS**: Convert to OpenAPI 3.0 with enterprise enhancements

  - **Payload Validation**: Validate JSON payloads against OAS schemas  - **Payload Validation**: Validate JSON payloads against OAS schemas



### RAML to OAS Conversion### RAML to OAS Conversion

- 📦 **ZIP File Upload** - Drag & drop or click to upload- 🚀 **Next.js 14** with App Router

- 🔄 **Multi-file Support** - Handles RAML projects with multiple folders and file references- 📦 **ZIP File Upload** - Drag & drop or click to upload

- 📋 **RAML 0.8 & 1.0** - Full support for both RAML versions- 🔄 **Multi-file Support** - Handles RAML projects with multiple folders and file references

- 🎯 **OpenAPI 3.0** - Converts to latest OAS specification- 📋 **RAML 0.8 & 1.0** - Full support for both RAML versions

- 💾 **Multiple Formats** - Download as JSON or YAML- 🎯 **OpenAPI 3.0** - Converts to latest OAS specification

- 🏢 **Production Ready** - Comprehensive validation and error handling- 💾 **Multiple Formats** - Download as JSON or YAML

- ✅ **Enterprise Enhancements** - Meets Barclays API governance standards

### OAS Payload Validation- 🏢 **Production Ready** - Comprehensive validation and error handling

- ✅ **Request/Response Validation** - Validate request bodies and responses against OAS schemas

- 🎯 **Path & Method Selection** - Choose specific endpoint and HTTP method### OAS Payload Validation (NEW)

- 🔗 **External $ref Support** - Resolves references across multiple OAS files- ✅ **Request/Response Validation** - Validate payloads against OAS schemas

- 📊 **Multi-file OAS** - Upload OAS as ZIP with external schema files- 🎯 **Path Parameter Support** - Handles `/users/{id}` style paths

- 🔍 **Detailed Errors** - Field-level error reporting with actual vs expected values- � **Comprehensive Checks** - Type, required, pattern, length, enum validation

- 📋 **Error Table** - Clear visualization of validation errors- 🔍 **Detailed Errors** - Field-level error reporting with expected values

- 🔄 **Back Navigation** - Return to validation form with all inputs preserved- 🔗 **$ref Resolution** - Resolves internal schema references

- 📊 **Error Table Display** - Clear, organized validation results

### UI & UX- 🚀 **Fast Validation** - Server-side schema validation

- 🎨 **Modern UI** - Clean, responsive design with Tailwind CSS

- ⚡ **Fast Processing** - Server-side processing with optimized parsing### UI & UX

- 📊 **Preview & Download** - View results and download immediately- 🎨 **Modern UI** - Clean, responsive design with Tailwind CSS

- 🔄 **Mode Toggle** - Easy switching between conversion and validation modes- ⚡ **Fast Processing** - Server-side processing with optimized parsing

- 💾 **State Persistence** - Form inputs retained when navigating back- 📊 **Preview & Download** - View results and download immediately

- 🔄 **Mode Toggle** - Easy switching between conversion and validation modes

## 🛠️ Installation

## 🛠️ Installation

### Prerequisites

### Prerequisites

- Node.js 18+ or 20+

- npm, yarn, or pnpm- Node.js 18+ or 20+

- npm, yarn, or pnpm

### Setup

### Setup

1. Clone the repository:

```bash1. Clone the repository:

git clone <your-repo-url>```bash

cd raml-to-oasgit clone <your-repo-url>

```cd raml-to-oas

```

2. Install dependencies:

```bash2. Install dependencies:

npm install```bash

# ornpm install

yarn install# or

# oryarn install

pnpm install# or

```pnpm install

```

3. Run the development server:

```bash3. Run the development server:

npm run dev```bash

# ornpm run dev

yarn dev# or

# oryarn dev

pnpm dev# or

```pnpm dev

```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## 📖 Usage

## 🚀 Usage

### RAML to OAS Conversion

The application supports two modes accessible via buttons at the top of the page.

1. Click **"RAML → OAS"** mode button

2. Upload your RAML file:### Mode 1: RAML to OAS Conversion

   - Single `.raml` file, or

   - `.zip` file containing RAML project with multiple files1. **Select Mode:**

3. Click **"Convert to OpenAPI"**   - Click "RAML → OAS" button

4. Preview the converted OAS

5. Download as JSON or YAML2. **Prepare your RAML files:**

   - Create a ZIP file containing your RAML project

### Payload Validation   - The main RAML file should be named `api.raml` or `main.raml` in the root

   - Include all referenced files (includes, traits, types, examples, etc.)

1. Click **"Validate Payload"** mode button

2. Upload your OAS file:3. **Upload and Convert:**

   - Single `openapi.yaml` file, or   - Drag and drop your ZIP file onto the upload area

   - `.zip` file containing OAS with external references   - Or click to browse and select your ZIP file

3. Enter validation details:   - Wait for the conversion to complete

   - **Path**: API endpoint (e.g., `/orders`, `/users/{id}`)

   - **Method**: HTTP method (GET, POST, PUT, DELETE, PATCH)4. **Download Results:**

   - **Type**: Request Body or Response   - Choose between JSON or YAML format

   - **Payload**: JSON data to validate   - Click "Download OAS" to save the converted specification

4. Click **"Validate"**   - Or copy to clipboard for immediate use

5. View validation results:

   - ✅ **Valid**: All fields match the schema### Mode 2: OAS Payload Validation (NEW)

   - ❌ **Invalid**: Detailed error table showing mismatches

6. Click **"← Back to Validation"** to modify and revalidate (all inputs preserved)1. **Select Mode:**

   - Click "Validate Payload" button

## 📁 Project Structure

2. **Prepare your OAS files:**

```   - Create a ZIP file containing your OpenAPI specification

raml-to-oas/   - Main file should be named `openapi.yaml`, `swagger.yaml`, or `api.yaml`

├── app/

│   ├── api/3. **Configure Validation:**

│   │   ├── convert/         # RAML to OAS conversion endpoint   - **API Path**: Enter the endpoint path (e.g., `/users`, `/users/{id}`)

│   │   └── validate/        # Payload validation endpoint   - **HTTP Method**: Select GET, POST, PUT, PATCH, or DELETE

│   ├── page.tsx             # Main page with mode toggle   - **Validation Type**: Choose Request Body or Response Body

│   └── layout.tsx           # App layout   - **JSON Payload**: Paste the JSON data to validate

├── components/

│   ├── FileUpload.tsx       # File upload component with validation form4. **Validate and Review:**

│   └── ConversionResult.tsx # Results display with back navigation   - Click "Validate" button

├── lib/   - ✅ **Valid**: See green success message

│   └── converter.ts         # Core conversion & validation logic   - ❌ **Invalid**: Review error table with field-level details

├── raml-sample-api/         # Sample RAML project for testing

│   ├── api.raml### When to Use Each Mode

│   ├── libraries/

│   ├── resources/**RAML → OAS** - Best for:

│   └── traits/- ✅ Generating OpenAPI documentation

└── OAS/- ✅ Using OAS-based tools (Swagger UI, Postman, code generators)

    └── oas.zip              # Sample multi-file OAS for testing- ✅ Implementing APIs with OAS-native frameworks

```- ✅ Meeting OpenAPI governance and compliance requirements



## 🧪 Testing**Validate Payload** - Best for:

- ✅ Testing API request/response payloads during development

### Sample Files Included- ✅ Debugging schema mismatches

- ✅ Ensuring contract compliance between frontend and backend

1. **RAML Sample** (`raml-sample-api/`):- ✅ Validating API examples in documentation

   - Multi-file RAML project with libraries, resources, and traits- ✅ Contract testing in CI/CD pipelines

   - Perfect for testing RAML → OAS conversion

### Example RAML Project Structure

2. **OAS Sample** (`OAS/oas.zip`):

   - Multi-file OpenAPI specification with external references```

   - Structure: `openapi.yaml` → `paths/` → `schemas/`my-api.zip

   - Perfect for testing payload validation├── api.raml              # Main RAML file

├── libraries/

### Validation Test Example│   ├── common-types.raml

│   └── error-types.raml

**Sample OAS Structure** (`OAS/oas.zip`):├── resources/

```│   ├── users/

openapi.yaml│   │   └── users.raml

├── paths/│   └── orders/

│   ├── users.yaml│       └── orders.raml

│   └── orders.yaml├── traits/

└── schemas/│   ├── pageable.raml

    ├── User.yaml│   └── secured.raml

    └── Order.yaml└── examples/

```    ├── user-example.json

    └── order-example.json

**Test Payload**:```

```json

{### Example OAS Project Structure (for Validation)

  "orderId": "o789",

  "userId": "u123",```

  "amount": 1500.50my-oas.zip

}└── openapi.yaml          # OpenAPI specification with schemas

``````



**Validation Settings**:**Sample openapi.yaml:**

- Path: `/orders````yaml

- Method: `POST`openapi: 3.0.0

- Type: `Request Body`paths:

  /users:

## 🚀 Build for Production    post:

      requestBody:

```bash        content:

npm run build          application/json:

npm start            schema:

```              $ref: '#/components/schemas/User'

components:

## 🔧 Technical Stack  schemas:

    User:

- **Framework**: Next.js 14.2.35 (App Router)      type: object

- **Language**: TypeScript      required: [id, name, email]

- **Styling**: Tailwind CSS      properties:

- **RAML Parser**: raml-1-parser        id:

- **YAML**: js-yaml          type: integer

- **ZIP Handling**: JSZip        name:

          type: string

## 📝 Key Features Explained          pattern: '^[a-zA-Z ]+$'

        email:

### External $ref Resolution          type: string

          format: email

The validation system properly handles external references in multi-file OAS:```



```yaml## 🏗️ Project Structure

# openapi.yaml

paths:```

  /orders:raml-to-oas/

    $ref: './paths/orders.yaml'├── app/

│   ├── api/

# paths/orders.yaml│   │   ├── convert/

post:│   │   │   └── route.ts       # OAS conversion endpoint

  requestBody:│   │   └── flatten/

    content:│   │       └── route.ts       # RAML flattening endpoint

      application/json:│   ├── layout.tsx             # Root layout

        schema:│   ├── page.tsx               # Home page with mode toggle

          $ref: '../schemas/Order.yaml'│   └── globals.css            # Global styles

├── components/

# schemas/Order.yaml (automatically resolved)│   ├── FileUpload.tsx         # File upload component

type: object│   └── ConversionResult.tsx   # Results display (both modes)

properties:├── lib/

  orderId: { type: string }│   └── converter.ts           # Conversion & flattening logic (2200+ lines)

  userId: { type: string }├── raml-sample-api/           # Sample multi-file RAML project

  amount: { type: number }│   ├── api.raml

```│   ├── libraries/

│   ├── resources/

### Comprehensive Validation│   ├── traits/

│   └── examples/

Validates against:├── BUILD_SUMMARY.md           # Development history

- ✅ Required fields├── FEATURE_SUMMARY.md         # Complete feature list

- ✅ Type checking (string, number, boolean, object, array)├── RAML_FLATTENING.md        # Flattening feature docs

- ✅ String patterns (regex)├── QUICKSTART.md             # Quick start guide

- ✅ String length (min/max)├── TESTING.md                # Testing instructions

- ✅ Number ranges (minimum/maximum)├── README.md                 # This file

- ✅ Enum values├── public/                   # Static assets

- ✅ Array items├── package.json

- ✅ Nested objects├── tsconfig.json

- ✅ Additional properties├── tailwind.config.js

└── next.config.js

## 🤝 Contributing```



1. Fork the repository## 🔧 Technology Stack

2. Create your feature branch (`git checkout -b feature/amazing-feature`)

3. Commit your changes (`git commit -m 'Add amazing feature'`)- **Framework:** Next.js 14 with App Router

4. Push to the branch (`git push origin feature/amazing-feature`)- **Language:** TypeScript

5. Open a Pull Request- **Styling:** Tailwind CSS

- **RAML Parser:** raml-1-parser

## 📄 License- **ZIP Handling:** JSZip

- **YAML Processing:** js-yaml

This project is licensed under the MIT License.

## 📝 Supported RAML Features

## 🙏 Acknowledgments

### ✅ Fully Supported

- Built with Next.js and TypeScript

- RAML parsing powered by raml-1-parser- RAML 0.8 and 1.0 specifications

- UI components styled with Tailwind CSS- Multi-file projects with includes

- Resource types and traits
- Data types and schemas
- Query parameters and headers
- Request and response bodies
- Security schemes (OAuth 2.0, Basic Auth, API Keys)
- Examples and descriptions
- Nested resources
- Base URI and protocols

### ⚠️ Partial Support

- Some advanced RAML 1.0 features may require manual review
- Complex annotations may not convert directly

## 🔍 API Reference

### POST /api/convert

Converts a RAML ZIP file to OpenAPI Specification.

**Request:**
- Content-Type: `multipart/form-data`
- Body: ZIP file containing RAML project

**Response:**
```json
{
  "success": true,
  "oas": { /* OpenAPI 3.0 specification */ },
  "yaml": "openapi: 3.0.0\n...",
  "filesProcessed": 5,
  "mainFile": "api.raml"
}
```

**Error Response:**
```json
{
  "error": "Error message",
  "details": "Stack trace (in development)"
}
```

## 🐛 Troubleshooting

### Common Issues

**"No main RAML file found"**
- Ensure your ZIP contains `api.raml` or `main.raml` in the root directory
- Or any `.raml` file in the root directory

**"RAML parsing errors"**
- Check that all included files are present in the ZIP
- Verify RAML syntax is valid
- Ensure file paths in includes match the actual file structure

**"File not found" during conversion**
- Make sure all referenced files use relative paths
- Check that file names match exactly (case-sensitive)

## 📦 Building for Production

```bash
# Build the application
npm run build

# Start production server
npm start
```

## 🧪 Development

```bash
# Run development server with hot reload
npm run dev

# Run linter
npm run lint

# Type check
npx tsc --noEmit
```

## 📄 License

MIT License - feel free to use this project for personal or commercial purposes.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 🔗 Resources

- [RAML Specification](https://raml.org/)
- [OpenAPI Specification](https://swagger.io/specification/)
- [Next.js Documentation](https://nextjs.org/docs)

## 📧 Support

If you encounter any issues or have questions, please open an issue on GitHub.

---

Built with ❤️ using Next.js and TypeScript
