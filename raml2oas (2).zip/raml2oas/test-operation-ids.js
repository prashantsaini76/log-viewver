import { convertRamlToOas } from './lib/converter.ts';
import * as fs from 'fs';

async function test() {
  console.log('Testing operationId generation...\n');

  const ramlContent = fs.readFileSync('test-operation-ids.raml', 'utf8');

  const files = {
    'test-operation-ids.raml': ramlContent
  };

  try {
    const result = await convertRamlToOas(files, 'test-operation-ids.raml');
    console.log('✅ SUCCESS! Conversion completed.\n');
    console.log('Generated OAS:\n');
    console.log(result.yaml);
  
    fs.writeFileSync('test-operation-ids-output.yaml', result.yaml);
    console.log('\n📝 Output written to test-operation-ids-output.yaml');
  } catch (error) {
    console.error('❌ Conversion failed:', error.message);
    if (error.stack) console.error(error.stack);
  }
}

test();
