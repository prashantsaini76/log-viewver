'use client';

import { useState, useEffect, useCallback } from 'react';

interface RegexMatch {
  match: string;
  index: number;
  groups?: { [key: string]: string };
}

export default function RegexTester() {
  const [pattern, setPattern] = useState('');
  const [flags, setFlags] = useState('g');
  const [testString, setTestString] = useState('');
  const [matches, setMatches] = useState<RegexMatch[]>([]);
  const [error, setError] = useState('');
  const [isMatch, setIsMatch] = useState<boolean | null>(null);

  const testRegex = useCallback(() => {
    setError('');
    setMatches([]);
    setIsMatch(null);

    if (!pattern) {
      return;
    }

    try {
      const regex = new RegExp(pattern, flags);
      const foundMatches: RegexMatch[] = [];

      if (flags.includes('g')) {
        // Global flag - find all matches
        let match;
        while ((match = regex.exec(testString)) !== null) {
          foundMatches.push({
            match: match[0],
            index: match.index,
            groups: match.groups
          });
          // Prevent infinite loop on zero-length matches
          if (match.index === regex.lastIndex) {
            regex.lastIndex++;
          }
        }
        setMatches(foundMatches);
        setIsMatch(foundMatches.length > 0);
      } else {
        // No global flag - find first match
        const match = regex.exec(testString);
        if (match) {
          foundMatches.push({
            match: match[0],
            index: match.index,
            groups: match.groups
          });
          setMatches(foundMatches);
          setIsMatch(true);
        } else {
          setIsMatch(false);
        }
      }

      // Also test with .test() method
      const testResult = new RegExp(pattern, flags.replace('g', '')).test(testString);
      if (!flags.includes('g')) {
        setIsMatch(testResult);
      }
    } catch (e) {
      setError(`Invalid regex: ${e instanceof Error ? e.message : 'Unknown error'}`);
      setIsMatch(null);
    }
  }, [pattern, flags, testString]);

  useEffect(() => {
    testRegex();
  }, [testRegex]);

  const highlightMatches = () => {
    if (!testString || matches.length === 0) {
      return testString;
    }

    const parts: JSX.Element[] = [];
    let lastIndex = 0;

    matches.forEach((match, idx) => {
      // Add text before match
      if (match.index > lastIndex) {
        parts.push(
          <span key={`text-${idx}`}>
            {testString.substring(lastIndex, match.index)}
          </span>
        );
      }

      // Add highlighted match
      parts.push(
        <span
          key={`match-${idx}`}
          className="bg-yellow-200 border-b-2 border-yellow-500 font-semibold"
          title={`Match ${idx + 1} at index ${match.index}`}
        >
          {match.match}
        </span>
      );

      lastIndex = match.index + match.match.length;
    });

    // Add remaining text
    if (lastIndex < testString.length) {
      parts.push(
        <span key="text-end">
          {testString.substring(lastIndex)}
        </span>
      );
    }

    return parts;
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6 space-y-4">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Regular Expression Pattern:
          </label>
          <div className="flex gap-2">
            <span className="flex items-center text-gray-600 font-mono text-lg">/</span>
            <input
              type="text"
              value={pattern}
              onChange={(e) => setPattern(e.target.value)}
              placeholder="[a-zA-Z0-9]+"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent font-mono"
            />
            <span className="flex items-center text-gray-600 font-mono text-lg">/</span>
            <input
              type="text"
              value={flags}
              onChange={(e) => setFlags(e.target.value)}
              placeholder="flags"
              className="w-24 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent font-mono"
              title="Regex flags: g (global), i (case-insensitive), m (multiline), s (dotAll), u (unicode), y (sticky)"
            />
          </div>
          <p className="mt-1 text-xs text-gray-500">
            Common flags: <code className="bg-gray-100 px-1 rounded">g</code> (global), 
            <code className="bg-gray-100 px-1 rounded ml-1">i</code> (case-insensitive), 
            <code className="bg-gray-100 px-1 rounded ml-1">m</code> (multiline)
          </p>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Test String:
          </label>
          <textarea
            value={testString}
            onChange={(e) => setTestString(e.target.value)}
            placeholder="Enter text to test against the regex pattern..."
            rows={6}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent font-mono text-sm"
          />
        </div>

        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded">
            <p className="font-semibold text-red-800">Error</p>
            <p className="text-red-700 text-sm">{error}</p>
          </div>
        )}

        {isMatch !== null && !error && pattern && (
          <div className={`${isMatch ? 'bg-green-50 border-green-500' : 'bg-orange-50 border-orange-500'} border-l-4 p-4 rounded`}>
            <p className={`font-semibold ${isMatch ? 'text-green-800' : 'text-orange-800'}`}>
              {isMatch ? 'Match Found' : 'No Match'}
            </p>
            <p className={`text-sm ${isMatch ? 'text-green-700' : 'text-orange-700'}`}>
              {isMatch 
                ? `Found ${matches.length} match${matches.length !== 1 ? 'es' : ''}`
                : 'The pattern does not match the test string'
              }
            </p>
          </div>
        )}

        {matches.length > 0 && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Highlighted Matches:
              </label>
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 font-mono text-sm whitespace-pre-wrap break-words">
                {highlightMatches()}
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Match Details:
              </label>
              <div className="space-y-2">
                {matches.map((match, idx) => (
                  <div key={idx} className="bg-gray-50 p-3 rounded-lg border border-gray-200">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-[#00AEEF]">Match {idx + 1}</span>
                      <span className="text-xs text-gray-500">Index: {match.index}</span>
                    </div>
                    <div className="font-mono text-sm bg-white p-2 rounded border border-gray-300">
                      {match.match}
                    </div>
                    {match.groups && Object.keys(match.groups).length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs font-semibold text-gray-600 mb-1">Captured Groups:</p>
                        {Object.entries(match.groups).map(([key, value]) => (
                          <div key={key} className="text-xs font-mono bg-[#e6f7fd] px-2 py-1 rounded mt-1">
                            <span className="text-[#00AEEF]">{key}:</span> {value}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
          <p className="text-sm text-blue-800">
            <span className="font-semibold">Quick Reference:</span><br/>
            <code className="bg-blue-100 px-1 rounded">\d</code> = digit, 
            <code className="bg-blue-100 px-1 rounded ml-1">\w</code> = word character, 
            <code className="bg-blue-100 px-1 rounded ml-1">\s</code> = whitespace<br/>
            <code className="bg-blue-100 px-1 rounded">^</code> = start of string, 
            <code className="bg-blue-100 px-1 rounded ml-1">$</code> = end of string, 
            <code className="bg-blue-100 px-1 rounded ml-1">.</code> = any character<br/>
            <code className="bg-blue-100 px-1 rounded">*</code> = 0 or more, 
            <code className="bg-blue-100 px-1 rounded ml-1">+</code> = 1 or more, 
            <code className="bg-blue-100 px-1 rounded ml-1">?</code> = 0 or 1<br/>
            <code className="bg-blue-100 px-1 rounded">[abc]</code> = character set, 
            <code className="bg-blue-100 px-1 rounded ml-1">(abc)</code> = capture group
          </p>
        </div>
      </div>
    </div>
  );
}
