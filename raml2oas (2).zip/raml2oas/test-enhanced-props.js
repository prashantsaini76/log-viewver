import { convertRamlToOas } from './lib/converter.ts';
import * as fs from 'fs';

async function test() {
  console.log('Testing enhanced properties...\n');

  const ramlContent = fs.readFileSync('test-enhanced-props.raml', 'utf8');

  const files = {
    'test-enhanced-props.raml': ramlContent
  };

  try {
    const result = await convertRamlToOas(files, 'test-enhanced-props.raml');
    console.log('✅ SUCCESS! Conversion completed.\n');
    console.log('Generated OAS:\n');
    console.log(result.yaml);
  
    fs.writeFileSync('test-enhanced-props-output.yaml', result.yaml);
    console.log('\n📝 Output written to test-enhanced-props-output.yaml');
  } catch (error) {
    console.error('❌ Conversion failed:', error.message);
    if (error.stack) console.error(error.stack);
  }
}

test();