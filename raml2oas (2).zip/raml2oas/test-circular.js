const fs = require('fs');
const { convertRamlToOas } = require('./lib/converter.ts');

async function test() {
  console.log('Testing circular reference in library...\n');

  const files = {
    'test-circular.raml': fs.readFileSync('test-circular.raml', 'utf8'),
    'test-circular-lib.raml': fs.readFileSync('test-circular-lib.raml', 'utf8')
  };

  console.log('Files loaded:');
  Object.keys(files).forEach(f => console.log(`  ${f}`));
  console.log('');

  try {
    const result = await convertRamlToOas(files, 'test-circular.raml');
    console.log('\n✅ Conversion successful! Circular reference was handled.');
    console.log('\nPaths:', Object.keys(result.oas.paths || {}));
  } catch (error) {
    console.error('\n❌ Error:', error.message);
    process.exit(1);
  }
}

test();
