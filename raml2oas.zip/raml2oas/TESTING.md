# Sample RAML Files for Testing

This directory contains sample RAML files to test the converter.

## Creating a Test ZIP

To create a test ZIP file:

1. Create a folder structure:
```
test-api/
├── api.raml
├── types/
│   └── user.raml
└── examples/
    └── user-example.json
```

2. Add the content from the examples below

3. ZIP the entire `test-api` folder

## Example 1: Simple API (api.raml)

```yaml
#%RAML 1.0
title: User Management API
version: v1
baseUri: https://api.example.com/{version}
mediaType: application/json

types:
  User:
    type: object
    properties:
      id:
        type: integer
        required: true
      name:
        type: string
        required: true
      email:
        type: string
        required: true
      age:
        type: integer
        minimum: 0

/users:
  get:
    description: Get all users
    queryParameters:
      page:
        type: integer
        default: 1
      limit:
        type: integer
        default: 10
    responses:
      200:
        body:
          application/json:
            type: User[]
  post:
    description: Create a new user
    body:
      application/json:
        type: User
    responses:
      201:
        body:
          application/json:
            type: User
      400:
        description: Bad request

/users/{userId}:
  get:
    description: Get user by ID
    responses:
      200:
        body:
          application/json:
            type: User
      404:
        description: User not found
  put:
    description: Update user
    body:
      application/json:
        type: User
    responses:
      200:
        body:
          application/json:
            type: User
  delete:
    description: Delete user
    responses:
      204:
        description: Successfully deleted
```

## Example 2: Multi-file with Includes

### Main file (api.raml)
```yaml
#%RAML 1.0
title: E-Commerce API
version: v2
baseUri: https://api.store.com/{version}

types:
  User: !include types/user.raml
  Product: !include types/product.raml

/users:
  get:
    responses:
      200:
        body:
          application/json:
            type: User[]
  post:
    body:
      application/json:
        type: User
    responses:
      201:
        body:
          application/json:
            type: User

/products:
  get:
    responses:
      200:
        body:
          application/json:
            type: Product[]
```

### types/user.raml
```yaml
#%RAML 1.0 DataType
type: object
properties:
  id:
    type: integer
  name:
    type: string
    minLength: 2
    maxLength: 100
  email:
    type: string
    pattern: ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$
  createdAt:
    type: datetime
```

### types/product.raml
```yaml
#%RAML 1.0 DataType
type: object
properties:
  id:
    type: integer
  name:
    type: string
  price:
    type: number
    minimum: 0
  category:
    type: string
    enum: [electronics, clothing, books, food]
  inStock:
    type: boolean
```

## Testing Instructions

1. Copy one of the examples above into appropriate files
2. Create a ZIP file containing the structure
3. Upload to the converter
4. Verify the OAS output contains all endpoints, types, and properties

## Expected Output

The converter should generate an OpenAPI 3.0 spec with:
- All endpoints converted to paths
- RAML types converted to components/schemas
- Query parameters and request bodies properly converted
- Response codes and content types maintained
- Includes properly resolved
