const { flattenRaml } = require('./lib/converter.ts');
const fs = require('fs');
const path = require('path');

// Read all files from raml-sample-api
const ramlDir = path.join(__dirname, 'raml-sample-api');

function readDirRecursive(dir, baseDir = dir) {
  const files = {};
  const items = fs.readdirSync(dir);
  
  for (const item of items) {
    const fullPath = path.join(dir, item);
    const stat = fs.statSync(fullPath);
    
    if (stat.isDirectory()) {
      Object.assign(files, readDirRecursive(fullPath, baseDir));
    } else {
      const relativePath = path.relative(baseDir, fullPath).replace(/\\/g, '/');
      files[relativePath] = fs.readFileSync(fullPath, 'utf8');
    }
  }
  
  return files;
}

async function test() {
  try {
    console.log('Reading RAML files...');
    const files = readDirRecursive(ramlDir);
    
    console.log('Files found:');
    Object.keys(files).forEach(f => console.log(`  - ${f}`));
    
    console.log('\nFlattening RAML...');
    const flattened = await flattenRaml(files, 'api.raml');
    
    console.log('\n=== FLATTENED RAML ===\n');
    console.log(flattened);
    
    // Save to file
    fs.writeFileSync('flattened-api.raml', flattened);
    console.log('\nSaved to flattened-api.raml');
    
  } catch (error) {
    console.error('Error:', error.message);
    console.error(error.stack);
  }
}

test();
