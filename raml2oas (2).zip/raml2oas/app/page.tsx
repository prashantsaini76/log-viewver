'use client';

import { useState } from 'react';
import FileUpload from '@/components/FileUpload';
import ConversionResult from '@/components/ConversionResult';

type ConversionMode = 'oas' | 'flatten' | 'flatten-oas';

export default function Home() {
  const [converting, setConverting] = useState(false);
  const [mode, setMode] = useState<ConversionMode>('oas');
  const [result, setResult] = useState<{
    success: boolean;
    data?: any;
    raml?: string;
    oas?: string;
    originalFile?: string;
    error?: string;
  } | null>(null);

  const handleFileUpload = async (file: File) => {
    setConverting(true);
    setResult(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      let endpoint = '/api/convert';
      if (mode === 'flatten') {
        endpoint = '/api/flatten';
      } else if (mode === 'flatten-oas') {
        endpoint = '/api/flatten-oas';
      }
      
      const response = await fetch(endpoint, {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        setResult({
          success: false,
          error: data.error || 'Conversion failed',
        });
      } else {
        // Handle different response structures for OAS vs Flatten
        if (mode === 'flatten') {
          setResult({
            success: true,
            raml: data.raml,
            originalFile: data.originalFile,
          });
        } else if (mode === 'flatten-oas') {
          setResult({
            success: true,
            oas: data.oas,
            originalFile: data.originalFile,
          });
        } else {
          setResult({
            success: true,
            data: data,
          });
        }
      }
    } catch (error) {
      setResult({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      });
    } finally {
      setConverting(false);
    }
  };

  const handleReset = () => {
    setResult(null);
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
      <div className="max-w-5xl mx-auto">
        <header className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            RAML to OAS Converter
          </h1>
          <p className="text-lg text-gray-700">
            Convert RAML to OpenAPI, or flatten RAML/OAS files into single documents
          </p>
        </header>

        {!result && (
          <div className="mb-8 flex justify-center gap-3 flex-wrap">
            <button
              onClick={() => setMode('oas')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                mode === 'oas'
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              RAML → OAS
            </button>
            <button
              onClick={() => setMode('flatten')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                mode === 'flatten'
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Flatten RAML
            </button>
            <button
              onClick={() => setMode('flatten-oas')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                mode === 'flatten-oas'
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Flatten OAS
            </button>
          </div>
        )}

        {!result ? (
          <FileUpload onUpload={handleFileUpload} isConverting={converting} mode={mode} />
        ) : (
          <ConversionResult result={result} onReset={handleReset} />
        )}

        <footer className="mt-16 text-center text-sm text-gray-600">
          <p>Supports RAML 0.8/1.0 and OpenAPI 3.0 with multi-file/folder references</p>
          <p className="mt-2">
            {mode === 'oas' 
              ? 'Converts RAML to OpenAPI 3.0 specification'
              : mode === 'flatten'
              ? 'Flattens all RAML files into a single api.raml file'
              : 'Flattens all OpenAPI files into a single openapi.yaml file'
            }
          </p>
        </footer>
      </div>
    </main>
  );
}
