# OpenAPI (OAS) Flattening Feature

## Overview

The OAS Flattening feature consolidates multi-file OpenAPI 3.0 projects into a single `openapi.yaml` file by resolving all external `$ref` references.

## What Gets Flattened

### ✅ Resolved
- External `$ref` references to other files (e.g., `$ref: './schemas/User.yaml'`)
- References with fragments (e.g., `$ref: './schemas.yaml#/User'`)
- Relative path references (`./`, `../`)
- Nested references (references within referenced files)
- Both YAML and JSON referenced files

### ✅ Preserved
- Internal `$ref` references (e.g., `$ref: '#/components/schemas/User'`)
- OpenAPI structure and metadata
- All paths, operations, and responses
- Component definitions
- Security schemes

## Example

### Before (Multi-File)

**openapi.yaml:**
```yaml
openapi: 3.0.0
info:
  title: My API
paths:
  /users:
    get:
      responses:
        '200':
          content:
            application/json:
              schema:
                $ref: './schemas/User.yaml'
```

**schemas/User.yaml:**
```yaml
type: object
properties:
  id:
    type: integer
  name:
    type: string
  address:
    $ref: './Address.yaml'
```

**schemas/Address.yaml:**
```yaml
type: object
properties:
  street: string
  city: string
```

### After (Flattened)

**openapi.yaml:**
```yaml
openapi: 3.0.0
info:
  title: My API
paths:
  /users:
    get:
      responses:
        '200':
          content:
            application/json:
              schema:
                type: object
                properties:
                  id:
                    type: integer
                  name:
                    type: string
                  address:
                    type: object
                    properties:
                      street: string
                      city: string
```

## How It Works

1. **Parse Main File**: Reads the main OpenAPI file (YAML or JSON)
2. **Find External Refs**: Recursively searches for `$ref` not starting with `#/`
3. **Resolve Paths**: Handles relative paths (`./`, `../`)
4. **Load Referenced Files**: Reads and parses referenced files
5. **Handle Fragments**: Navigates to specific paths in referenced files (e.g., `#/components/schemas/User`)
6. **Inline Content**: Replaces `$ref` with actual content
7. **Recursive Processing**: Resolves refs within resolved content
8. **Output**: Single YAML file with all content inlined

## Use Cases

✅ **Simplified Distribution**: Share a single file without folder structure  
✅ **Tool Compatibility**: Some tools don't support multi-file OpenAPI  
✅ **Documentation**: Create standalone API documentation  
✅ **Version Control**: Easier to track changes in a single file  
✅ **CI/CD**: Simplify build pipelines that expect single files  

## Usage

### Via Web UI
1. Click "Flatten OAS" button
2. Upload OpenAPI project as ZIP
3. Download single `openapi.yaml` file

### Via API
```bash
curl -X POST http://localhost:3000/api/flatten-oas \
  -F "file=@openapi-project.zip" \
  -o openapi.yaml
```

## Supported File Types

- ✅ YAML files (`.yaml`, `.yml`)
- ✅ JSON files (`.json`)
- ✅ Mixed YAML and JSON references
- ✅ Nested folder structures

## Reference Resolution

### Supported Reference Types

1. **Relative file references**
   ```yaml
   $ref: './schemas/User.yaml'
   $ref: '../common/Error.yaml'
   ```

2. **File with fragment**
   ```yaml
   $ref: './schemas.yaml#/User'
   $ref: './definitions.json#/components/schemas/Product'
   ```

3. **Internal references** (preserved as-is)
   ```yaml
   $ref: '#/components/schemas/User'
   $ref: '#/components/responses/NotFound'
   ```

### Path Normalization

The flattener automatically normalizes paths:
- `./file.yaml` → `file.yaml`
- `../schemas/User.yaml` → `schemas/User.yaml` (from parent)
- Multiple `../` are resolved correctly

## Limitations

- ❌ HTTP/HTTPS URLs not fetched (e.g., `$ref: 'https://...'`)
- ❌ Circular references may cause issues
- ⚠️ Very large files may impact performance
- ⚠️ Comments in referenced files may be lost

## Error Handling

### File Not Found
If a referenced file is not in the ZIP:
```
Referenced file not found: schemas/User.yaml
```
The original `$ref` is preserved.

### Invalid References
Malformed references are logged and preserved as-is.

### Parse Errors
If a file cannot be parsed (invalid YAML/JSON), an error is returned.

## Performance

- **Small projects** (<10 refs): <200ms
- **Medium projects** (10-50 refs): 200-800ms
- **Large projects** (50+ refs): 800-3000ms

## Comparison with RAML Flattening

| Feature | RAML Flattening | OAS Flattening |
|---------|----------------|----------------|
| **Input** | RAML files | OpenAPI files |
| **References** | `!include`, `uses:` | `$ref` |
| **Output** | Single RAML | Single YAML |
| **Internal Refs** | Inlined with prefixes | Preserved |
| **External Refs** | All inlined | All inlined |

## Tips

### Best Practices
1. ✅ Include all referenced files in the ZIP
2. ✅ Use relative paths in `$ref`
3. ✅ Test the flattened file with validators
4. ✅ Keep a backup of the original multi-file structure

### Common Issues

**Issue**: References not resolved  
**Solution**: Ensure all files are in the ZIP and paths match exactly

**Issue**: Circular references  
**Solution**: Refactor to use internal `#/components` refs for shared definitions

**Issue**: Large output file  
**Solution**: Consider keeping some internal `#/components` refs

## Example Projects

### Simple API
```
api.zip/
├── openapi.yaml (main file)
├── schemas/
│   ├── User.yaml
│   └── Product.yaml
└── responses/
    └── Errors.yaml
```

### Complex API
```
api.zip/
├── openapi.yaml
├── paths/
│   ├── users.yaml
│   └── products.yaml
├── components/
│   ├── schemas/
│   │   ├── User.yaml
│   │   └── Product.yaml
│   ├── responses/
│   │   └── Errors.yaml
│   └── parameters/
│       └── Common.yaml
```

## Testing

Test with the included sample or create your own:
```bash
# Create test structure
mkdir -p oas-sample/schemas
echo "openapi: 3.0.0" > oas-sample/openapi.yaml
echo "type: object" > oas-sample/schemas/User.yaml

# Zip it
cd oas-sample && zip -r ../oas-sample.zip * && cd ..

# Upload via UI or API
curl -X POST http://localhost:3000/api/flatten-oas \
  -F "file=@oas-sample.zip"
```

## Future Enhancements

- [ ] Support for OpenAPI 3.1
- [ ] Preserve comments option
- [ ] Selective flattening (choose which refs to inline)
- [ ] Circular reference detection and handling
- [ ] HTTP URL fetching
- [ ] JSON Schema $id resolution
- [ ] Validation before/after flattening

---

**Status**: ✅ Production Ready  
**Version**: 1.0  
**Last Updated**: December 2025
